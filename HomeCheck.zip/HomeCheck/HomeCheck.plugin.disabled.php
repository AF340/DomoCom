<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/
require_once(dirname(__FILE__).'/class/HMalarmePeople.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensor.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensorRadio.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSMS.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeEmail.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeGPIO.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeActionVocal.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeCommandeVocale.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeURL.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeShell.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeConf.class.php');

//Création des commandes vocales d'activation ou de désactivation de l'alarmefunction Plugin_SwitchWireVocal_vocal_command(&$response,$actionUrl)

function Plugin_Alarme_vocal_command(&$response,$actionUrl)
{
	global $conf;
	$alarme_Manager = new AlarmeCommandeVocale("r");
	$alarmes = $alarme_Manager->populate();

	if($alarmes!= null)
	{
		foreach($alarmes as $alarme)
		{
			$response['commands'][] = array(
			'command'=>$conf->get('VOCAL_ENTITY_NAME').' '.htmlspecialchars_decode($alarme->getCommande(),ENT_QUOTES),
			'callback'=>'plugin_alarme_vocal_action',
			'parameters' => array(	"Type"=>$alarme->getType()),
			'url'=>$actionUrl.'?action=plugin_alarme_vocal_action&webservice=true&Type='.$alarme->getType(),
			'confidence'=>(float)$alarme->getConfidence());
		}
	}
	
	$genericRadioManager = new AlarmeSensorRadio();

    $genericRadios = $genericRadioManager->populate();
    foreach ($genericRadios as $genericRadio) {
		if (!$genericRadio->isalarm) {
			if (!empty($genericRadio->onCommand)) {
				$response['commands'][] = array(
					'command'=>$conf->get('VOCAL_ENTITY_NAME').', '.$genericRadio->onCommand,
					'url'=>$actionUrl.'?action=HomeCheckRadio_vocal_change_state&engine='.$genericRadio->id.'&state=1',
					'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
			}
			if (!empty($genericRadio->offCommand)) {
				$response['commands'][] = array(
					'command'=>$conf->get('VOCAL_ENTITY_NAME').', '.$genericRadio->offCommand,
					'url'=>$actionUrl.'?action=HomeCheckRadio_vocal_change_state&engine='.$genericRadio->id.'&state=0',
					'confidence'=>('0.90'+$conf->get('VOCAL_SENSITIVITY')));
			}
		}
    }
}

//Appel du nouveau client vocal, suite commande vocale activation ou désactivation
function plugin_alarme_vocal_action ($text,$confidence,$parameters,$myUser)
{
	switch ($parameters["Type"])
	{
		//Les actions suite au retour vocal
		case "On":
			Plugin_Alarme_Activation();

		break;
		
		case "Off":
			Plugin_Alarme_Desactivation();
		break;
	}
}

//Lancement de la routine, 
function Plugin_Alarme_Activation()
{
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarme_conf->setValue("1");
	$alarme_conf->save();

	//On stop les programme de detections
	plugin_alarme_load_stopSensor_GPIO();

	//relance des sensor mode AD (activation ou désactivation par GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),0,0);
	}
	
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
	
	$talk="Alarme activé!!, vous avez ".$alarme_conf->getValue()." secondes avant l'activation des dètecteurs";
	/*
	try
	{
		$cli = new Client();
		$cli->connect();
		$cli->talk($talk);
		$cli->disconnect();
	}
	catch (Exception $e) 
	{
		$erreur= 'Erreur lors de la diction de la phrase : '.$talk.', erreur : '.$e->getMessage().'<br>';
	}
	*/
	//lancement des sensor mode sensor (Détecteur branché sur GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorGPIO'));
	
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
	
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),$alarme_conf->getValue(),1);
	}
	return $erreur;
}

function Plugin_Alarme_Desactivation()
{
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarme_conf->setValue("0");
	$alarme_conf->save();
	
	//diction
	$talk="Alarme désactivée, bien venu chez vous";
	/*
	try
	{
		$cli = new Client();
		$cli->connect();
		$cli->talk($talk);
		$cli->disconnect();
	}
	catch (Exception $e)
	{
		$erreur='Erreur lors de la disction de la phrase : '.$talk.', erreur : '.$e->getMessage().'<br>';
	}
	*/
	
	//On stop les programmes de detections
	plugin_alarme_load_stopSensor_GPIO();
	//relance des sensor mode AD (activation ou désactivation par GPIO)
	$alarme_Manager = new AlarmeSensor("r");
	$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
	foreach($alarmes as $alarme)
	{
		plugin_alarme_load_sensor_GPIO($alarme->getNumGPIO(),"0","0");
	}

	//Si l'alarme à été déclenchée, il faut stoper les GPIO activé lors du déclenchemrent 
	$alarme_Manager = new AlarmeGPIO("r");
	$alarmesGPIO = $alarme_Manager->populate();
	foreach($alarmesGPIO as $alarme)
	{
		$numGPIO=(int)$alarme->getNumGPIO();
		$stateGPIO=((int)$alarme->getStateGPIO()== 1) ? 0 : 1;
		Gpio::mode($numGPIO,'out');
		Gpio::write($numGPIO,$stateGPIO);
	}
	return $erreur;
}

//Fonction appelé pour déclencher l'alarme et donc les actions planifiées
function Plugin_Alarme_Start_Action()
{	
	global $conf;
	header('Content-Type: text/html; charset=utf-8');
	
	//Modification de la surveillance
	$alarme_conf = new AlarmeConf();
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	$alarme_conf->setValue("2");
	$alarme_conf->save();
	echo "Surveillance toujours active <br>";
	
	//Diction des commandes vocales
	$alarme_Manager = new AlarmeActionVocal("r");
	$alarmesVocales = $alarme_Manager->populate();
	/*
	foreach($alarmesVocales as $alarme)
	{
		
		try
		{
			$MessageVocal=$alarme->getMessageVocal();
			$cli = new Client();
			$cli->connect();
			$cli->talk(htmlspecialchars_decode($MessageVocal,ENT_QUOTES));
			$cli->disconnect();
			echo 'Diction envoyé : '.htmlspecialchars_decode($MessageVocal,ENT_QUOTES).' <br>';
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de la disction de la phrase : '.$alarme->getMessageVocal().', erreur : '.$e->getMessage().'<br>';
		}
		
	}
	*/
	//Envoie sms
	$alarme_Manager = new AlarmeSMS("r");
	$alarmesSMS = $alarme_Manager->populate();
	foreach($alarmesSMS as $alarme)
	{
		try
		{
			plugin_alarme_sendSms($alarme->getIdentifiant_user(), $alarme->getIdentifiant_mdp(), $conf->get('VOCAL_ENTITY_NAME')." : ".$alarme->getMessage());
			echo 'SMS Envoyé (Destinataire : '.$alarme->getIdentifiant_user().')<br>';
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'envoye du sms : '.$e->getMessage().'(Destinataire : '.$alarme->getIdentifiant_user().')<br>';
		}
	}
	
	//Bascule des GPIO
	$alarme_Manager = new AlarmeGPIO("r");
	$alarmesGPIO = $alarme_Manager->populate();
	foreach($alarmesGPIO as $alarme)
	{
		try
		{
			$numGPIO=(int)$alarme->getNumGPIO();
			$stateGPIO=(int)$alarme->getStateGPIO();
			Gpio::mode($numGPIO,'out');
			Gpio::write($numGPIO,$stateGPIO);
			echo 'GPIO numéro : '.$numGPIO.', Basculé à l\'état : '.$stateGPIO.'<br>';
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de la bascule du GPIO numéro : '.$numGPIO.', erreur : '.$e->getMessage().'<br>';
		}
	}
		
	//Execution des URL
	$alarme_Manager = new AlarmeURL("r");
	$alarmesURL = $alarme_Manager->loadAll(array('type'=>'ActionUrl'));
	foreach($alarmesURL as $alarme)
	{
		try
		{
			if (function_exists('curl_version'))
			{
				//Si CURL est activé, tester l'URL
				$url=htmlspecialchars_decode($alarme->getUrl(),ENT_QUOTES);
				$ch = curl_init();
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				if(curl_exec($ch))
				{
					echo 'URL exécutée : '.$url;
					echo ', Retour de l\'URL :'.curl_multi_getcontent($ch).'<br>';
				}
				else
				{
					echo 'Erreur lors de l\'exécution de l\'URL : '.curl_error($ch);
					echo '. Code d\'erreur HTML: '.curl_getinfo($ch, CURLINFO_HTTP_CODE).'<br>';
				}
				curl_close($ch);
			}
			else
			{
				echo 'Impossible de tester l\'URL de Yana-Server, "cURL" manquant sur ce RPI <br>';
			}
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'envoye de l\'email au destinataire : '.$alarme->getEmailAddr() .', erreur : '.$e->getMessage().'<br>';
		}
	}
	
	//Execution des commandes Shell
	$alarme_Manager = new AlarmeShell("r");
	$alarme_Shell=$alarme_Manager->populate();
	foreach($alarme_Shell as $alarme)
	{
		try
		{
			$Shell=htmlspecialchars_decode($alarme->getShell(),ENT_QUOTES);
			$returnString = system($Shell,$returnState);
			if (!$returnState)
			{
				echo 'Commande Shell : "'.$alarme->getShell() .'" exécutée avec succés : ';
				print_r($returnString);
				echo '<br>';
			}
			else
			{
				echo 'Erreur lors de l\'exécution de la commande shell : '.$alarme->getShell() .', erreur : ';
				print_r($returnString);
				echo '<br>';
			}
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'exécution de la commande shell : '.$alarme->getShell() .', erreur : '.$e->getMessage().'<br>';
		}
	}
	
	//Envoie des e-mails
	$alarme_Manager = new AlarmeEmail("r");
	$alarmesEmail = $alarme_Manager->populate();
	foreach($alarmesEmail as $alarme)
	{
		try
		{
			$smtpServerAddr=$alarme->getSmtpServerAddr();
			$smtpServerPort=$alarme->getSmtpServerPort();
			$smtpServerSSL=$alarme->getSmtpServerSSL();
			$smtpServerUser=$alarme->getSmtpServerUser();
			$smtpServerPasswd=$alarme->getSmtpServerPasswd();
			$EmailAddr=$alarme->getEmailAddr();
			$EmailExp=$alarme->getEmailExp();
			$EmailOjt=$alarme->getEmailOjt();
			$EmailMsg=$alarme->getEmailMsg();
			$return = plugin_alarme_sendEmail($smtpServerAddr,$smtpServerPort,$smtpServerSSL,$smtpServerUser,$smtpServerPasswd,$EmailAddr,$EmailExp,$EmailOjt,$EmailMsg);
			echo 'Email envoyé à '.$alarme->getEmailAddr().'<br>';
		}
		catch (Exception $e) 
		{
			echo 'Erreur lors de l\'envoye de l\'email au destinataire : '.$alarme->getEmailAddr() .', erreur : '.$e->getMessage().'<br>';
		}
	}
	

	//prise de photo ou video
	try
	{
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_CameraDirectory"));				
		$absolute_path=$alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
		$Type = $alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf= $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
		$ResH = $alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
		$ResV = $alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraTime"));
		$Time = $alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
		$Option = $alarme_conf->getValue();
		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
		$CopyDirectory = $alarme_conf->getValue();		

		if ($Type=="Photo")
		{
			$name=time();
			system('raspistill '.$Option.' -w '.$ResV.' -h '.$ResH.'-n -o '.$absolute_path.$name.'.jpg');
			echo "Photo prise sous le nom: ".$name.".jpg <br>";
			if ($alarme_conf->getValue()!="")
			{
				copy($absolute_path.$name.'.jpg', $alarme_conf->getValue().$name.'.jpg');
				echo "Photo copiée sur le montage/nom :".$alarme_conf->getValue().$name.".jpg <br>";
			}
		}			
		elseif($Type=="Video")
		{
			$name=time();
			system('raspivid '.$Option.' -t '.$Time.' -w '.$ResV.' -h '.$ResH.' -n -o '.$absolute_path.$name.'.h264');
			system('MP4Box -fps 30 -add '.$absolute_path.$name.'.h264 '.$absolute_path.$name.'.mp4 > /dev/null');
			unlink($absolute_path.$name.'.h264');
			echo "Video capturée sous le nom: ".$name.".h264 <br>";
			
			if ($CopyDirectory!="")
			{
				copy($absolute_path.$name.'.mp4', $CopyDirectory.$name.'.mp4');
				echo "Vidéo copiée sur le montage/nom :".$CopyDirectory.$name.".mp4 <br>";
			}
		}
	}
	catch(Exception $e) 
	{
			echo 'Erreur lors de la prise de photo ou de vidéo, erreur : '.$e->getMessage().'<br>';
	}
}

function plugin_alarme_load_sensor_GPIO($GPIO, $time, $mode)
{
	//mode = 1 pour les sensor, mode = 0 pour les activations/désactivations
	$command=dirname(__FILE__)."/AlarmeDetector ".$GPIO." ".$time." ".$mode." > /dev/null &";
	$return = exec($command, $out, $return);
	return ($return);
}

function plugin_alarme_load_stopSensor_GPIO()
{
	$command=dirname(__FILE__)."/AlarmeStop";
	$return = exec($command, $out, $return);
	return ($return);
}

function HomeCheck_sendSms($message)
{
	 switch(strval($message)){

        case "15333060":
			$source='cuisine';
			break;
		case "11301988":
			$source='salon';
			break;
		case "7123300":
			$source='sdb';
			break;
		default:
			$source='Other';
	 }
	$message=$source.' '.$message;
	return $message;
}


function plugin_alarme_sendSms($user, $pass, $message)
{
	$ch = curl_init();
	$url = "https://smsapi.free-mobile.fr/sendmsg?user=".$user."&pass=".$pass."&msg=".htmlspecialchars_decode($message,ENT_QUOTES);
	
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_exec($ch);
	
	//retour code http
	$return = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	return ($return);
}


function plugin_alarme_sendEmail($smtpServerAddr,$smtpServerPort,$smtpServerSSL,$smtpServerUser,$smtpServerPasswd,$EmailAddr,$EmailExp,$EmailOjt,$EmailMsg)
{ 
		require_once('swiftmailer-5.x/lib/swift_required.php');	
		$transport = Swift_SmtpTransport::newInstance($smtpServerAddr,$smtpServerPort,$smtpServerSSL)
			->setUsername(htmlspecialchars_decode($smtpServerUser,ENT_QUOTES))
			->setPassword(htmlspecialchars_decode($smtpServerPasswd,ENT_QUOTES));
		$mailer = Swift_Mailer::newInstance($transport);
		$message = Swift_Message::newInstance()
			->setSubject(htmlspecialchars_decode($EmailOjt,ENT_QUOTES))
			->setFrom(array(htmlspecialchars_decode($EmailAddr,ENT_QUOTES) => $EmailExp))
			->setTo(htmlspecialchars_decode($EmailAddr,ENT_QUOTES))
			->setBody(htmlspecialchars_decode($EmailMsg,ENT_QUOTES));
		$mailer->send($message, $error);
}

function plugin_alarme_setting_menu()
{
	global $_;
	echo '<li '.((isset($_['section']) && ($_['section']=='Home_Check'))?'class="active"':'').'><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral"><i class="fa fa-angle-right"></i> Home_Check </a></li>';
}


function plugin_alarme_onglet($onglet,$sousOnglet)
{
	if(isset($onglet))
	{
		?>
		<div class="span9 userBloc">
			<span class="span9 plugin_swv_titre">
				<h1>Configuration</h1>
				<p>Alarme, lier des detecteurs et des actions résultantes</p>
			</span>
		</div>
		<div class="span9 userBloc">
			<ul class="nav nav-tabs nav-justified">
				<li <?php if($onglet=="ADAlarme"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral">Gestion des personnes </a></li>
				<li <?php if($onglet=="Sensor"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Sensor&sousblock=SensorRXRADIO">Déclencheurs/détecteurs</a></li>	
				<li <?php if($onglet=="Actions"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsSMS">Actions</a></li>
				<li <?php if($onglet=="Widget"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Widget&sousblock=WidgetGeneral">Widget</a></li>
				
			</ul>
			<?php
			if($onglet=="ADAlarme")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="AlarmeGeneral"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral">Général</a></li>
				<li <?php if($sousOnglet=="AlarmeVocales"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeVocales">Vocal</a></li>
				<li <?php if($sousOnglet=="AlarmeGPIO"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="AlarmeURL"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeURL">URL</a></li>
				</ul>
				<?php
			}
			if($onglet=="Sensor")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="SensorRXRADIO"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Sensor&sousblock=SensorRXRADIO">DECLENCHEUR RADIO</a></li>
				<li <?php if($sousOnglet=="SensorTXRADIO"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Sensor&sousblock=SensorTXRADIO">DETECTEUR RADIO</a></li>
				<li <?php if($sousOnglet=="SensorGPIO"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Sensor&sousblock=SensorGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="SensorURL"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Sensor&sousblock=SensorURL">URL</a></li>
				
				</ul>
				<?php
			}
			if($onglet=="Actions")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="ActionsSMS"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsSMS">SMS</a></li>
				<li <?php if($sousOnglet=="ActionsEmail"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsEmail">Email</a></li>
				<li <?php if($sousOnglet=="ActionsGPIO"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsGPIO">GPIO</a></li>
				<li <?php if($sousOnglet=="ActionsVocales"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsVocales">Vocal</a></li>
				<li <?php if($sousOnglet=="ActionsCamera"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionCamera">Camera</a></li>
				<li <?php if($sousOnglet=="ActionsURL"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsURL">URL</a></li>
				<li <?php if($sousOnglet=="ActionsShell"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Actions&sousblock=ActionsShell">Shell</a></li>

				</ul>
				<?php
			}
			if($onglet=="Widget")
			{
				?>
				<ul class="nav nav-pills nav-justified">
				<li <?php if($sousOnglet=="WidgetGeneral"){echo 'class="active"';} ?>><a href="setting.php?section=Home_Check&block=Widget&sousblock=WidgetGeneral">Général</a></li>
				</ul>
				<?php
			}
			?>
		</div>
		<?php
	}
}

//Page Configuration
function plugin_alarme_setting_page() {
	global $myUser,$_,$conf;
	
	//si une page envoie une erreur, affichage de celle-ci
	if(isset($_['section']) && $_['section']=='Home_Check' && isset($_['error'])) {
		echo $_['error'];
	}
	//Page Alarme
	if(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeGeneral') {
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeGeneral");
			$HomeCheckManager = new Home_Check();
			//$HomeChecks = $HomeCheckManager->populate();
			$selected =  new Home_Check();
        
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $HomeCheckManager->getById($_['id']);
			}
			?>
	 
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<h2><i class="fa fa-book"></i> Gestion des membres</h2>
					
					<legend>Ajouter Membre</legend>

                    <div class="left">

					<label for="nameHomeCheck">Nom</label>
					<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
					<input type="text" id="nameHomeCheck" value="<?php echo $selected->name; ?>" placeholder="Arthur..."/>
					
					<label for="descriptionHomeCheck">Description</label>
					<input type="text"  value="<?php echo $selected->description; ?>" id="descriptionHomeCheck" placeholder="Papa " />

					<label for="IMEIHomeCheck">IMEI associé</label>
					<input type="text" value="<?php echo $selected->imei; ?>" name="IMEIHomeCheck" id="IMEIHomeCheck" placeholder="identifie une personne..." />
					<label for="ISADMINHomeCheck">Est Admin</label>
					<input type="number" value="<?php echo $selected->isadmin; ?>" name="ISADMINHomeCheck" id="ISADMINHomeCheck" placeholder="1 si admin,0 sinon" />
					<label for="PASSHomeCheck">Mot de passe (Numerique uniquement)</label>
					<input type="number" value="<?php echo $selected->password; ?>" name="PASSHomeCheck" id="PASSHomeCheck" placeholder="que des chiffres" />
					
					
					<label for="MobileHomeCheck">Numéro de portable</label>
					<input type="text" value="<?php echo $selected->nummobile; ?>" name="MobileHomeCheck" id="MobileHomeCheck" placeholder="Pour envoie SMS" />
					
					<label for="EmailHomeCheck">Adresse email</label>
					<input type="text" value="<?php echo $selected->email; ?>" name="EmailHomeCheck" id="EmailHomeCheck" placeholder="Pour envoie email" />
					
					<label for="IsClientServHomeCheck">Client Fixe servant de relai</label>
					<input type="number" value="<?php echo $selected->isclientserv; ?>" name="IsClientServHomeCheck" id="IsClientServHomeCheck" placeholder="Client fixe pour relai sms" />
					
					<label for="Location">Position (Ne pas Toucher)</label>
					<input type="text" value="<?php echo $selected->location; ?>" name="Location" id="Location" placeholder="ne pas Toucher" />
					
					<label for="IPLOCALE">IP locale (Ne pas Toucher)</label>
					<input type="text" value="<?php echo $selected->ip; ?>" name="IPLOCALE" id="IPLOCALE" placeholder="ne pas Toucher" />
					
					
					<label for="ISATHomeCheck">Présence locale (Ne pas Toucher)</label>
					<input type="text" value="<?php echo $selected->state; ?>" name="ISATHomeCheck" id="ISATHomeCheck" placeholder="ne pas Toucher" />
				   
                     <div class="clear"></div>
                     <br/>
					 <button type="button" id="plugin_AddHomeCheck" class="btn">Enregistrer</button>
					 <br><br>
					<legend  >Personnes enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadPersonnes();
						?>
					</div>
										
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeVocales')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeVocales");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<h2><i class="fa fa-book"></i> Explications</h2>
					<p>Vous pouvez enregistrer une commande vocale d'activation et de désactivation de la surveillance </p>
					<p>Celles-ci sont facultatives</p>
					<p>Pour les commandes vocales de désactivation, il est préférable d'utiliser des phrases complexes comme un mot de passe.</p>
					<p>La commande vocales faisant partie des commandes vocales que Yana doit écouter, elle est visible dans l'inventaire des commandes vocales du Dashboard et sur les clients Yana</p>
						<legend>Cette commande permet d'activer l'alarme</legend>
						<label for="CommandeVocaleOn">Commande vocale d'activation de la surveillance  :</label>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : '; ?><textarea rows="4" cols="50" name="CommandeVocaleOn" id ="CommandeVocaleOn" value="" placeholder="active l'alarme de la maison"/></textarea>
						<br>
						<button type="button" id="submitAlarme_AddCommandes_VocaleOn" class="btn">Enregistrer</button>
						<br><br>
						<legend>Factultatif : cette commande permet d'arréter de la surveillance </legend>
		
						<label for="CommandeVocaleOff">Factultatif : Commande vocale d'arrét de l'alarme :</label>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : ';?><textarea rows="4" cols="50" name="CommandeVocaleOff" id ="CommandeVocaleOff" value="" placeholder="cette phrase pour désactiver l'alarme de la maison est impossible à trouver."/></textarea>
						<br><br>
						<button type="button" id="plugin_alarme_addCommande_VocaleOff" class="btn">Enregistrer</button>
					<br><br>
					<legend  >Commandes vocales enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadCommandes_Vocales();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeGPIO");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Vous pouvez paramétrer ici les GPIO qui pourront activer ou désactiver la surveillance en changeant d'état.</legend>
							<p><i class="fa fa-exclamation-triangle"></i> Il faut activer ou désactiver une fois la surveillance pour que les interrupts se mettent en place.</p>
							<p>Si le RPI redémarre, les interrupts ne sont plus exécutées, cependant, les URL fontionnent.</p>
							
							<input type="hidden" name="SensorType" id="SensorType" value="SensorADGPIO"/>
							<label for="descriptionADGPIO">Description du périphérique:</label>
							<input type="text" name="descriptionADGPIO" id ="descriptionADGPIO" value="" placeholder="Digicode, lecteur d'empreintes, RFID etc.."/>
							
							<label for="numADGPIO"> Numéro du GPIO (WiringPi) :</label>
							<input type="number" name="numADGPIO" id ="numADGPIO" value="" placeholder="1,2,3 etc.."/>
							<button type="button" id="submitAlarme_AddADSensor" class="btn">Enregistrer</button>
						</fieldset>
					</form>
					<legend>GPIO surveillé pour l'activation ou la désactivation de la surveillance </legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadADSensor();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='ADAlarme' && $_['sousblock'] =='AlarmeURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("ADAlarme","AlarmeURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br>
					<legend>Vous pouvez activer ou désactiver la surveillance depuis un autre périphérique, en éxécutant une URL.</legend>
					<p>Pour des questions de sécurité, ces URL ne sont pas disponible directement, il faudra fournir le token :</p>
					URL d'activation de la surveillance  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Activation&token='.$myUser->getToken();
						?>
					</code>
					<br>
					URL de désactivation de la surveillance  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Desactivation&token='.$myUser->getToken();
						?>
					</code>
					<br>
					URL pour switcher, si la surveillance est activé, elle est arrétée, si elle est arrétée, ca l'active  :
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Switch&token='.$myUser->getToken();
						?>
					</code>
					<br><br>
					<p>Ces URL sont aussi accéssible sans token, si la requette vient de l'addresse IP Local 127.0.0.1.</p>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Sensor' && $_['sousblock'] =='SensorRXRADIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorRXRADIO");
			// recepteurs: relais lumiere, alarme ...
			$RadioManager = new AlarmeSensorRadio();
			$Radios = $RadioManager->populate();
			$selected =  new AlarmeSensorRadio();
        
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $RadioManager->getById($_['id']);
			}
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
                    <legend>Ajouter/Modifier un relais radio</legend>

                    <div class="left">
						<input type="hidden" id="id" value="<?php echo $selected->id; ?>">
						<input type="hidden" name="SensorType" id="SensorType" value="SensorRXRADIO"/>
                        <label for="descriptionGenericRadio">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGenericRadio" placeholder="Relais sous le canapé…" />

                            <label for="radioCodeGenericRadioOn">Code radio ON</label>
                            <input type="text" value="<?php echo $selected->radiocodeOn; ?>" name="radioCodeGenericRadioOn" id="radioCodeGenericRadioOn" placeholder="1:1234" />
                            
							<label for="radioCodeGenericRadioOff">Code radio OFF</label>
                            <input type="text" value="<?php echo $selected->radiocodeOff; ?>" name="radioCodeGenericRadioOff" id="radioCodeGenericRadioOff" placeholder="1:1234" />
                           
							<label for="radioCodeGenericIsAlarm">Relai Alarme</label>
                            <input type="text" value="<?php echo $selected->isalarm; ?>" name="radioCodeGenericIsAlarm" id="radioCodeGenericIsAlarm" placeholder="1:Oui 0:Non" />
							
                            <label for="onGenericRadio">Commande vocale "ON" associée</label>
                            <input type="text" value="<?php echo $selected->onCommand; ?>" name="onGenericRadio" id="onGenericRadio"  placeholder="Allume la lumière, Ouvre le volet…"/>

                            <label for="offGenericRadio">Commande vocale "OFF" associée</label>
                            <input type="text" value="<?php echo $selected->offCommand; ?>" name="offGenericRadio" id="offGenericRadio" placeholder="Eteinds la lumière, Ferme le volet…"/>
                            
                        </div>
						<div class="clear"></div>
						<br/>
						
                        <br/><button type="button" id="submitAlarme_AddRadio" class="btn">Enregistrer</button>
                    
					<legend>Déclencheurs/détecteurs</legend>
					
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensorRadio("SensorRXRADIO");
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Sensor' && $_['sousblock'] =='SensorTXRADIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorTXRADIO");
			// emetteurs: detecteur presence...
			$RadioManager = new AlarmeSensorRadio();
			//$Radios = $RadioManager->populate();
			$selected =  new AlarmeSensorRadio();
        
			//Si on est en mode modification
			if (isset($_['id'])) {
				$selected = $HomeCheckManager->getById($_['id']);
			}
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
					<fieldset>
                    <legend>Ajouter/Modifier un relais radio</legend>

                    <div class="left">
						<input type="hidden" name="SensorType" id="SensorType" value="SensorTXRADIO"/>
                        <label for="descriptionGenericRadio">Description</label>
                        <input type="text"  value="<?php echo $selected->description; ?>" id="descriptionGenericRadio" placeholder="Relais sous le canapé…" />

                            <label for="radioCodeGenericRadioOn">Code radio ON</label>
                            <input type="text" value="<?php echo $selected->radiocodeOn; ?>" name="radioCodeGenericRadioOn" id="radioCodeGenericRadioOn" placeholder="1:1234" />
                            
							<label for="radioCodeGenericRadioOff">Code radio OFF</label>
                            <input type="text" value="<?php echo $selected->radiocodeOff; ?>" name="radioCodeGenericRadioOff" id="radioCodeGenericRadioOff" placeholder="1:1234" />
							
							<input type="hidden" name="onGenericRadio" id="onGenericRadio" value=""/>
							<input type="hidden" name="offGenericRadio" id="offGenericRadio" value=""/>
                        </div>

                        <div class="clear"></div>
                        <br/><button type="button" id="submitAlarme_AddRadio" class="btn">Enregistrer</button>
                    
                    </fieldset>
                    <br/>
					</form>
					<legend>Déclencheurs/détecteurs</legend>
					
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensorRadio("SensorTXRADIO");
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Sensor' && $_['sousblock'] =='SensorGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorGPIO");
			
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Enregistrez les GPIO à surveiller (détecteur de mouvement, Adruino, etc ...)</legend>
							<input type="hidden" name="SensorType" id="SensorType" value="SensorGPIO"/>
							<label for="descriptionSensor">Description du détecteur :</label>
							<input type="text" name="descriptionSensor" id ="descriptionSensor" value="" placeholder="Détecteur de mouvement, etc.."/>
							
							<label for="numGPIO"> Numéro du GPIO (WiringPi) :</label>
							<input type="number" name="numGPIO" id ="numGPIO" value="" placeholder="1,2,3 etc.."/>
							<button type="button" id="submitAlarme_AddSensor" class="btn">Enregistrer</button>
							
							<legend>Paramètres </legend>
							<label for="plugin_alarme_timetoStart">Temps entre l'activation de la surveillance , et la mise en marche des détecteurs (seconde):</label>
							<input type="text" name="plugin_alarme_timetoStart" id ="plugin_alarme_timetoStart" value="<?php echo $alarme_conf->getValue(); ?>" />
							<button type="button" id="submit_plugin_alarme_timetoStart" class="btn">Enregistrer</button><br/>
							<span id="plugin_alarme_test_span3"></span>
							
						</fieldset>
					</form>
					<legend>Déclencheurs/détecteurs</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadSensor();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	//page Déclencheur URL
		elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Sensor' && $_['sousblock'] =='SensorURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Sensor","SensorURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br>
					<legend>Vous pouvez déclencher l'alarme depuis un autre périphérique, en éxécutant une URL</legend>
					<p>Pour des questions de sécurité, cette URL n'est pas disponible directement, il faudra fournir le token :</p>
					<code>
						<?php
						echo 'http://'.$_SERVER['SERVER_ADDR'].'/yana-server/action.php?action=Plugin_Alarme_Start_Action&token='.$myUser->getToken();
						?>
					</code>
					<br><br>
					<p>Cette URL est aussi accéssible sans token si la requette vient de l'addresse IP Local 127.0.0.1, donc un programme local</p>
				</div>
			</div>
		<?php
		}
	}

	//Page "Actions SMS"
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions'&& $_['sousblock'] =='ActionsSMS')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsSMS");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Enregistrez les sms à envoyer en cas d'alerte, cette fonctionnalité est disponible pour les utilisateurs Free mobile</p>
					<p>Si vous êtes chez cet opérateur, vous pouvez activer dans les options de votre compte "Notification par sms" et récupérer le mot de passe ainsi que l'identifiant utilisateur.</p>					
					<form>						
						<fieldset>
							<legend>Envoiez un sms lors d'une détection</legend>
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="SMS"/>
							<label for="AlarmeUserId">Identifiant utilisateur (free mobile):</label>
							<input type="text" name="AlarmeUserName" id ="AlarmeUserId" value=""/>
							
							<label for="AlarmePassId">Mot de passe (free mobile):</label>
							<input type="text" name="AlarmePassName" id ="AlarmePassId" value=""/>
							
							<label for="AlarmeMsgId">Message à envoyer (free mobile):</label>
							<?php echo $conf->get('VOCAL_ENTITY_NAME'); ?>
							<input type="text" name="AlarmeMsgName" id ="AlarmeMsgId" value=""/>
							<button type="button" id="submitAlarme_test_SMS" class="btn">Tester SMS</button>
							<span id="plugin_alarme_test_span" style="display:none;"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_SMS" class="btn">Enregistrer</button>
						</fieldset>	
					</form>	
					<legend  >Envoie de SMS configuré</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_SMS();
						?>
					</div>
				</div>
			</div>
		<?php		
		}
	}
	
	
	//Page "Actions Email"
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionsEmail')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsEmail");
			
			?>
			<div class="span9 userBloc">
				<br/>
				<p>Enregistrez les adresses emails à contacter en cas d'alerte.</p>
				<legend>Envoie d'un Email lors d'une detection</legend>
				<div class="left">
					<form>						
						<fieldset>
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="Email"/>
							
							<label for="smtpServerAddr">Adresse du relais SMTP:</label>
							<input type="text" name="smtpServerAddr" id ="smtpServerAddr" value="" placeholder="smtp.laposte.net, smtp.live.com"/>
							<i class="fa fa-question-circle fa-lg" id="IconeEmailInfobulle"></i>
							
							<label for="smtpServerPort">Port du serveur SMTP:</label>
							<input type="number" name="smtpServerPort" id ="smtpServerPort" value="" placeholder="25, 465, 587"/>
							
							<label for="smtpServerSSL">Protocol d'accés au serveur SMTP:</label>
							<input type="text" name="smtpServerSSL" id ="smtpServerSSL" value=""  placeholder="ssl, tls"/>
							
							<label for="smtpServerUser">Identifiant:</label>
							<input type="text" name="smtpServerUser" id ="smtpServerUser" placeholder="Jean.Michel"/>
							
							<label for="smtpServerPasswd">Mot de passe:</label>
							<input type="password" name="smtpServerPasswd" id ="smtpServerPasswd" placeholder="MotDePass" />
							
							<label for="EmailAddr">Adresse Email destinataire:</label>
							<input type="text" name="EmailAddr" id ="EmailAddr" value="" placeholder="jean-michel@msn.fr"/>
							
							<label for="EmailExp">Nom de l'expéditeur:</label>
							<input type="text" name="EmailExp" id ="EmailExp" value="" placeholder="Yana Alerte"/>
							
							<label for="EmailOjt">Objet de l'Email:</label>
							<input type="text" name="EmailOjt" id ="EmailOjt" value="" placeholder="Yana: On nous attaque !!!!"/>
							
							<label for="EmailMsg">Texte du message:</label>
							<input type="text" name="EmailMsg" id ="EmailMsg" value="" placeholder="J'active le lanceur de haches!!"/>

							<button type="button" id="submitAlarme_test_Email" class="btn">Tester Email</button>
							<span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_Email" class="btn">Enregistrer</button>
						</fieldset>
					</form>
				</div>
				<div id="EmailInfobulle" style="display:none;" class="right">
					Exemple de paramétre déja testés:
					<br/>
					Laposte :<br/>
						&nbsp;&nbsp;serveur : smtp.laposte.net<br/>
						&nbsp;&nbsp;port : 465<br/>
						&nbsp;&nbsp;sécusiré : ssl<br/>
						&nbsp;&nbsp;utilisateur : utilisateur (sans @laposte.net)<br/>
						&nbsp;&nbsp;mot de pass : mdp<br/>
					<br/>	
					Hotmail :<br/>
						&nbsp;&nbsp;serveur : smtp.live.com<br/>
						&nbsp;&nbsp;port : 587<br/>
						&nbsp;&nbsp;sécusiré : tls<br/>
						&nbsp;&nbsp;utilisateur : utilisateur@msn.com<br/>
						&nbsp;&nbsp;mot de pass : mdp<br/>
					<br/>
					Gmail (ssl) (Nécessite de débloquer un paramétre de sécurité dans Gmail):<br/>
						&nbsp;&nbsp;serveur : smtp.gmail.com<br/>
						&nbsp;&nbsp;port : 465<br/>
						&nbsp;&nbsp;sécusiré : ssl<br/>
						&nbsp;&nbsp;utilisateur : utilisateur@gmail.com<br/>
						&nbsp;&nbsp;mot de pass : mdp<br/>
					<br/>
					Gmail (tls) (Nécessite de débloquer un paramétre de sécurité dans Gmail):<br/>
						&nbsp;&nbsp;serveur : smtp.gmail.com<br/>
						&nbsp;&nbsp;port : 587<br/>
						&nbsp;&nbsp;sécusiré : tls<br/>
						&nbsp;&nbsp;utilisateur : utilisateur@gmail.com<br/>
						&nbsp;&nbsp;mot de pass : mdp<br/>
				</div>
				
				<legend>Envoie d'Email configuré</legend>
				<div class="span9 userBloc" id="xhrAlarme">
					<?php
					echo plugin_alarme_LoadActions_Email();
					?>
				</div>				
			</div>
		<?php
		}		
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionsGPIO')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsGPIO");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Déclenchez une liste de GPIO en cas d'alerte, celles-ci pouvant alimenter/déclancher des hauts parleurs, des relais, des lanceurs de haches, etc... </p>
					
					<form action="action.php?action=plugin_alarme_test_email" method="POST">						
						<fieldset>
							<legend>Changement d'un GPIO en cas de détection</legend>
							<input type="hidden" name="AlarmeTypeName" id="AlarmeTypeId" value="GPIO"/>
							
							<label for="descriptionGPIO"> Description GPIO :</label>
							<input type="text" name="descriptionGPIO" id ="descriptionGPIO" value="" placeholder="Lanceur de haches, haut parleur, etc.."/>
							
							<label for="numGPIO"> Numéro du GPIO (WiringPi) :</label>
							<input type="number" name="numGPIO" id ="numGPIO" value="" placeholder="1,2,3 etc.."/>
							
							<label for="stateGPIO"> Etat du GPIO en cas d'alerte:</label>
							<input type="number" name="stateGPIO" id ="stateGPIO" value="" placeholder="0 ou 1"/>
							
							<button type="button" id="submitAlarme_test_GPIO" class="btn">Tester la bascule du GPIO</button>
							<br/>
							<span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_GPIO" class="btn">Enregistrer</button>
						</fieldset>
					</form>
					<legend  >GPIO Configuré</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_GPIO();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionsVocales')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsVocales");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Enregistrez les messages vocaux que Yana prononcera en cas d'alerte.</p>
					
					<form>
						<fieldset>
							<legend>Ces messages seront disctés en cas d'alerte</legend>
							<label for="MessageVocal">Message vocal :</label>
							<textarea rows="4" cols="50" name="MessageVocal" id ="MessageVocal" value="" placeholder="Je suis Yana, intelligence artifielle de défence et lanceuse de haches professionnelle"/></textarea>
							<button type="button" id="submitAlarme_test_Vocal" class="btn">Tester la diction</button>
							<br/>
							<span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_AddActions_Vocal" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					<legend  >Actions vocales enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActions_Vocales();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionCamera')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsCamera");
			
			//chemin d'enregistrement des photos
			$alarme_conf = new AlarmeConf("r");
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
			$Type = $alarme_conf->getValue();
		
			$alarme_conf= $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
			$ResH = $alarme_conf->getValue();

			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
			$ResV = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraTime"));
			$Time = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
			$Option = $alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
			$CopyDirectory = $alarme_conf->getValue();
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<p>Prendre des photos ou des videos en cas d'alerte</p>
					<p>Pour cela, la caméra doit déja étre configuré, comme dans le plugin Caméra  <i class="fa fa-question-circle fa-lg" id="IconeCameraInfobulle"></i></p>
					<div id="CameraInfobulle" style="display:none;" class="right">
					  <p>
						Avant de pouvoir utiliser ce plugin, vous devez avoir branché la caméra RPI, puis vous devez executer les commandes suivantes dans le terminal du raspberry pi :
						<br/><code>
							sudo apt-get update && sudo apt-get upgrade
						</code><br/>
						Puis tapez<br/>
						<code>
							sudo raspi-config 
						</code><br/>
						Puis allez dans "camera" et sélectionnez "enable", redemarrez et tapez<br/>
						<code>
							sudo usermod -a -G video www-data
						</code><br/>
						Puis<br/>
						<code>
							sudo echo 'SUBSYSTEM=="vchiq",GROUP="video",MODE="0660"' > /etc/udev/rules.d/10-vchiq-permissions.rules
						</code><br/>
						Et enfin<br/>
						<code>
							sudo chown -R www-data:www-data /var/www/yana-server/plugins/Home_Check/camera
						</code><br/>
							Redémarrez et c'est ok :)
						<br/>
							Auteur : Idleman Encore lui :)
					  </p>
					</div>
					<br/>
					<form>
						<fieldset>
							<legend>Camera</legend>
							<label for="Plugin_Alarme_Camera">Type de capture :</label>
							<select class="input-large" name="Plugin_Alarme_Camera" id="Plugin_Alarme_Camera">
								<option value="Photo"<?php if ($Type=="Photo"){ echo 'selected';}?> > Photo</option>
								<option value="Video"<?php if ($Type=="Video"){ echo 'selected';}?>>Video</option>
							</select>
							<div id="Plugin_Alarme_Photo" <?php if ($Type!="Photo"){ echo 'style="display:none;"';}?> class="right">
								<legend>Photo</legend>
								<label for="Plugin_Alarme_Resolution_V">Résolution largeur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_V" id ="Plugin_Alarme_Resolution_V" value="<?php if ($Type=="Photo"){ echo $ResV;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_Resolution_H">Résolution hauteur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_H" id ="Plugin_Alarme_Resolution_H" value="<?php if ($Type=="Photo"){ echo $ResH;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_CameraOption">Options Raspistill (facultatif):</label>
								<input type="text" name="Plugin_Alarme_CameraOption" id ="Plugin_Alarme_CameraOption" value="<?php if ($Type=="Photo"){ echo $Option;}?>" placeholder="-hf -vf ..."/>
								
								<label for="Plugin_Alarme_CameraCopyDirectory">Copier la photo sur un montage réseau : </label>
								<input type="text" name="Plugin_Alarme_CameraCopyDirectory" id ="Plugin_Alarme_CameraCopyDirectory" value="<?php if ($Type=="Photo"){ echo $CopyDirectory;}?>" placeholder="/media/photo/"/>

								<br/>
								<br/>
							</div>
							<div id="Plugin_Alarme_Video" <?php if ($Type!="Video"){ echo 'style="display:none;"';}?> class="right">
								<legend>Video</legend>
								
								<label for="Plugin_Alarme_Resolution_vid_V">Résolution largeur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_vid_V" id ="Plugin_Alarme_Resolution_vid_V" value="<?php if ($Type=="Video"){ echo $ResV;}?>" placeholder="400"/>
								
								<label for="Plugin_Alarme_Resolution_vid_H">Résolution hauteur:</label>
								<input type="number" name="Plugin_Alarme_Resolution_vid_H" id ="Plugin_Alarme_Resolution_vid_H" value="<?php if ($Type=="Video"){ echo $ResH;}?>" placeholder="400"/>

								<label for="Plugin_Alarme_TimeToCapture">Temps de capture (en milliseconde):</label>
								<input type="number" name="Plugin_Alarme_TimeToCapture" id ="Plugin_Alarme_TimeToCapture" value="<?php if ($Type=="Video"){ echo $Time;}?>" placeholder="5000"/>
								
								<label for="Plugin_Alarme_CameraOption_vid">Options Raspivid (facultatif):</label>
								<input type="text" name="Plugin_Alarme_CameraOption_vid" id ="Plugin_Alarme_CameraOption_vid" value="<?php if ($Type=="Video"){ echo $Option;}?>" placeholder="-hf -vf ..."/>
							
								<label for="Plugin_Alarme_CameraCopyDirectory_vid">Copier la vidéo sur un montage réseau : </label>
								<input type="text" name="Plugin_Alarme_CameraCopyDirectory_vid" id ="Plugin_Alarme_CameraCopyDirectory_vid" value="<?php if ($Type=="Video"){ echo $CopyDirectory;}?>" placeholder="/media/video/" />
							</div>
							
							<button type="button" id="submitAlarme_Camera_Test" class="btn">Tester la capture</button><span id="plugin_alarme_test_span"></span>
							<br/><br/>
							<button type="button" id="submitAlarme_Camera_Add" class="btn">Enregistrer</button>
							<span id="plugin_alarme_save_span"></span>
							<br/>
						</fieldset>	
					</form>
					
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadCamera();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionsURL')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsURL");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Ces URL seront executées en cas d'alerte</legend>
							<input type="hidden" name="Plugin_Alarme_TypeURL" id="Plugin_Alarme_TypeURL" value="ActionUrl"/>
							<input type="text"name="Plugin_Alarme_ActionURL" id ="Plugin_Alarme_ActionURL" value="" placeholder="http://192.168.0.1/yana-server/index.php"/>
							<button type="button" id="submitAlarme_test_URL" class="btn">Tester l'URL</button>
							<br>
							<span id="plugin_alarme_test_span"></span>
							<br>
							<button type="button" id="submitAlarme_AddActions_URL" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					<legend  >URL enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionsURL();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
		elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Actions' && $_['sousblock'] =='ActionsShell')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Actions","ActionsShell");
			?>
			<div class="span9 userBloc">
				<div class="left">
					<br/>
					<form>
						<fieldset>
							<legend>Vous pouvez rentrer des actions Shell ici, elles seront exécutées en cas d'alerte</legend>
							<p>Les commandes sont exécutées par l'interface, donc par l'utilisateur www-data, cet utilisateur à des droits restreints sur le système..
							</p>
							<input type="hidden" name="Plugin_Alarme_TypeShell" id="Plugin_Alarme_TypeShell" value="ActionShell"/>
							<input type="text"name="Plugin_Alarme_ActionShell" id ="Plugin_Alarme_ActionShell" value="" placeholder="/usr/local/bin/monExec"/>
							<button type="button" id="submitAlarme_test_Shell" class="btn">Tester la commande Shell</button>
							<br>
							<span id="plugin_alarme_test_span"></span>
							<br>
							<button type="button" id="submitAlarme_AddActions_Shell" class="btn">Enregistrer</button>
						</fieldset>	
					</form>
					<legend  >Commandes Shell enregistrées</legend>
					<div id="xhrAlarme">
						<?php
						echo plugin_alarme_LoadActionsShell();
						?>
					</div>
				</div>
			</div>
		<?php
		}
	}
	elseif(isset($_['section']) && $_['section']=='Home_Check'&& $_['block'] =='Widget' && $_['sousblock'] =='WidgetGeneral')
	{
		if($myUser!=false)
		{
			plugin_alarme_onglet("Widget","WidgetGeneral");
			
			$alarme_conf = new AlarmeConf();
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_RefreshWidget"));				
			$plugin_alarme_RefreshWidget=$alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_RefreshWidgetPhoto"));				
			$plugin_alarme_RefreshWidget_photo=$alarme_conf->getValue();
			
			$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_WidgetCameraOption"));				
			$plugin_alarme_WidgetCameraOption=$alarme_conf->getValue();
			
			?>
			<div class="span9 userBloc">
				<div class="left">
					<fieldset>
						<span>
						<label for="plugin_alarme_RefreshWidget"> Fréquence de rafraichissement du widget (milliseconde) :</label>
						<input type="number" name="plugin_alarme_RefreshWidget" id ="plugin_alarme_RefreshWidget" value="<?php echo $plugin_alarme_RefreshWidget; ?>"/>
						<button onclick="plugin_alarme_updateRefreshPhoto(this)" type="button" class="btn">
						<i class="plugin_alarme_button fa "></i></button>
						</span>
						
						<span>
						<label for="plugin_alarme_RefreshWidgetPhoto"> Fréquence de rafraichissement de la photo du widget (milliseconde) :</label>
						<input type="number" name="plugin_alarme_RefreshWidgetPhoto" id ="plugin_alarme_RefreshWidgetPhoto" value="<?php echo $plugin_alarme_RefreshWidget_photo; ?>"/>
						<button onclick="plugin_alarme_updateRefreshPhoto(this)" type="button" class="btn">
						<i class="plugin_alarme_button fa "></i></button>
						</span>
						
						<span>
						
						<label for="plugin_alarme_WidgetCameraOption"> Option des commandes Raspistill pour la photo du widget  :</label>
						<input type="text" name="plugin_alarme_WidgetCameraOption" id ="plugin_alarme_WidgetCameraOption" value="<?php echo $plugin_alarme_WidgetCameraOption; ?>" placeholder="-hf -vf ..."/>
						<button onclick="plugin_alarme_updateRefreshPhoto(this)" type="button" class="btn">
						<i class="plugin_alarme_button fa "></i></button>
						</span>
					</fieldset>
					
				</div>
			</div>
		<?php
		}
	}
}

function plugin_alarme_action()
{
	global $_,$myUser,$conf;
	switch($_['action'])
	{
		//Declenchement appel URL des actions d'alarme par 
		//Save ID
        case 'plugin_save_HomeCheck':
			if($myUser->can('Home_Check','c') && isset($_['nameHomeCheck']))
             {
                    $HomeCheckManager = new Home_Check();
                    $Home_Check = !empty($_['id']) ? $HomeCheckManager->getById($_['id']): new Home_Check();
                    $Home_Check->name = $_['nameHomeCheck'];
                    $Home_Check->description = $_['descriptionHomeCheck'];
                    $Home_Check->imei = $_['IMEIHomeCheck'];
                    $Home_Check->state = $_['ISATHomeCheck'];
					$Home_Check->isadmin=$_['ISADMINHomeCheck'];
					$Home_Check->password=$_['PASSHomeCheck'];
					$Home_Check->nummobile=$_['MobileHomeCheck'];
					$Home_Check->email=$_['EmailHomeCheck'];
					$Home_Check->isclientserv=$_['IsClientServHomeCheck'];
					$Home_Check->room = 1;
					$Home_Check->alarm=0;
					$Home_Check->ip='';
					$Home_Check->location='';
                    $Home_Check->save();
                    
					echo plugin_alarme_LoadPersonnes();
                }
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
            break;
			
		case 'HomeCheck_save_Radio':
            if($myUser->can('Home_Check','c') )
             {
                    $RadioManager = new AlarmeSensorRadio();

                    if (empty($_['descriptionGenericRadio'])) {
                        throw new Exception("Le nom est obligatoire");
                    }
                   // if (!is_numeric($_['radioCodeGenericRadio'])) {
                   //     throw new Exception("Le code radio est obligatoire et doit être numerique");
                   // }

                    $genericRadio = !empty($_['id']) ? $RadioManager->getById($_['id']): new AlarmeSensorRadio();
                   
                    $genericRadio->description = $_['descriptionGenericRadio'];
                    $genericRadio->type = $_['SensorType'];
                    $genericRadio->onCommand = $_['onGenericRadio'];
                    $genericRadio->offCommand = $_['offGenericRadio'];
                    
                    $genericRadio->radiocodeOn = $_['radioCodeGenericRadioOn'];
                    $genericRadio->radiocodeOff = $_['radioCodeGenericRadioOff'];
					
					$genericRadio->isalarm = $_['radioCodeGenericIsAlarm'];
                    $genericRadio->save();
                    //$response['message'] = 'Relais enregistré avec succès';
					echo plugin_alarme_LoadSensorRadio($_['SensorType']);
			 };
            break;
		case 'HomeCheckRadio_vocal_change_state':
            global $_,$myUser;
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('plugin_genericradio', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
                HomeCheckradio_plugin_change_state($_['engine'], $_['state']);
                $response['responses'][0]['sentence'] = Personality::response('ORDER_CONFIRMATION');
            } catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;

		case 'HomeCheck_commands_execute':
            global $_,$myUser;
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('plugin_HomeCheck', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
                HomeCheck_plugin_update_state($_['imei'], $_['state']);
                $response['responses'][0]['sentence'] = Personality::response('ORDER_CONFIRMATION');
            } catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		case 'HomeCheck_control_execute':
			global $_,$myUser;
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('plugin_HomeCheck', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				if ($_['check']==1) {
					$code=HomeCheck_whois(1);
					}
				else {
					$code=HomeCheck_whois(0);
				}
				
				$response['responses'][0]['sentence'] =$code;
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_SetAlarm':
			global $_,$myUser;
			try {
				if (!$myUser->can('plugin_HomeCheck', 'u')) {
						throw new Exception(
							'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
						);
				}
				$status=$_['status'];
				setAlarm($status);	
				//add action to stop physical alarm
				
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_AlarmStatus':
			$response=HomeCheck_alarmStatus();;
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
			
            break;
				
		case 'HomeCheck_AlarmDetect':
			global $_,$myUser;
			try {
				if (!$myUser->can('plugin_HomeCheck', 'u')) {
						throw new Exception(
							'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
						);
				}
				$delay=$_['alarmdelay'];
				$token=$myUser->getToken();
				
				$code=HomeCheck_whois(1);
				if ($code==0) {
					setAlarm(1);
					$cmd='python '.dirname(__FILE__).'/alarm.py '.$token.'_'.$delay;
					//exec($cmd . " > /dev/null &"); TODO
					$response=1;
				}
				else {
					$response=0;
				}
			
			} catch (Exception $e) {
                $response="0";
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		case 'HomeCheck_GetLanIP':
			$lan = Monitoring::internalIp();
			$response =$lan;
			$json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_SetIp':
			global $_,$myUser;
			try {
				$ip=$_['IP'];
				$imei=$_['IMEI'];
				$code=HomeCheck_SetLocalIP($ip,$imei);
				$response =$code;
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
			
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
			
		case 'HomeCheck_SetPos':
			global $_,$myUser;
			try {
				$pos=$_['POS'];
				$imei=$_['IMEI'];
				$code=HomeCheck_SetPos($pos,$imei);
				$response =$code;
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
			
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
		
		
		
		case 'HomeCheck_admin_execute':
			global $_,$myUser;
            try {
                $response['responses'][0]['type'] = 'talk';
                if (!$myUser->can('plugin_HomeCheck', 'u')) {
                    throw new Exception(
                        'Je ne vous connais pas, ou alors vous n\'avez pas le droit, je refuse de faire ça!'
                    );
                }
				$code=HomeCheck_whoisadmin($_['imei']);
				$response['responses'][0]['sentence'] =$code;
			} catch (Exception $e) {
                $response['responses'][0]['sentence'] = Personality::response('WORRY_EMOTION').'! '.$e->getMessage();
            }
            $json = json_encode($response);
            echo ($json=='[]'?'{}':$json);
            break;
				
		case 'Plugin_Alarme_Start_Action':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				Plugin_Alarme_Start_Action();
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		case 'HomeCheck_ReceiverDetect':
			global $_,$myUser;
			
			$code=$_['code'];
			$Message=HomeCheck_sendSms($code);
			
			$alarme_Manager = new AlarmeSMS("r");
			$alarmesSMS = $alarme_Manager->populate();
			foreach($alarmesSMS as $alarme)
			{
				try
				{
					plugin_alarme_sendSms($alarme->getIdentifiant_user(), $alarme->getIdentifiant_mdp(), $Message);
					echo 'SMS Envoyé (Destinataire : '.$alarme->getIdentifiant_user().')<br>';
				}
				catch (Exception $e) 
				{
					echo 'Erreur lors de l\'envoye du sms : '.$e->getMessage().'(Destinataire : '.$alarme->getIdentifiant_user().')<br>';
				}
			}
			break;
			
		//Activation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Activation':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				Plugin_Alarme_Activation();
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		//Désactivation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Desactivation':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				Plugin_Alarme_Desactivation();
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		//Désactivation par URL des détecteurs 
		case 'Plugin_Alarme_Start_Switch':
			if($_SERVER['REMOTE_ADDR']=="127.0.0.1"||$myUser->can('Home_Check',"r"))
			{
				$alarme_conf = new AlarmeConf("r");
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
				
				
				if ($alarme_conf->getValue()=='1')
				{
					Plugin_Alarme_Desactivation();
				}
				elseif ($alarme_conf->getValue()=='0')
				{
					Plugin_Alarme_Activation();
				}
			}
			else
			{
				echo('Action non autorisé');
			}
		break;
		
		//Action aprés ordre vocal association ancien client yana
		case 'plugin_alarme_vocal_action':
			if(($myUser->can('Home_Check',"r"))&&(isset($_['Type'])))//exception temporaire pour le yana scan sans token
			{
				switch ($_['Type'])
				{
					//Les actions suite au retour vocal
					case "On":
						$error=Plugin_Alarme_Activation();
						if($error==null)
							{
								$response = array('responses'=>array(array('type'=>'talk','sentence'=>talk(Personality::response('ORDER_CONFIRMATION')))));
								$json = json_encode($response);
								echo ($json=='[]'?'{}':$json);
							}
							else
							{
								$response = array('responses'=>array(
								array('type'=>'talk','sentence'=>'Une erreur est survenue!, '.$error)));
								echo json_encode($response);
							}
					break;
					
					case "Off":
						$error=Plugin_Alarme_Desactivation ();
						if($error==null)
							{
								$response = array('responses'=>array(array('type'=>'talk','sentence'=>talk(Personality::response('ORDER_CONFIRMATION')))));
								$json = json_encode($response);
								echo ($json=='[]'?'{}':$json);
							}
							else
							{
								$response = array('responses'=>array(
								array('type'=>'talk','sentence'=>'Une erreur est survenue!, '.$error)));
								echo json_encode($response);
							}
					break;
				}
			}
			else
			{
				echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_add_Sensor':
			if($myUser->can('Home_Check','c')&& isset($_['type']) && isset($_['descriptionSensor'])&& isset($_['numGPIO']))
			{
				$alarme_Manager = new AlarmeSensor();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setDescription($_['descriptionSensor']);
				$alarme_Manager->setNumGPIO(trim($_['numGPIO']));
				$alarme_Manager->save();
				if ($_['type']=="SensorGPIO")
				{
					echo plugin_alarme_LoadSensor();
				}
				elseif($_['type']=="SensorADGPIO")
				{
					echo plugin_alarme_LoadADSensor();
				}
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_sms':
			if($myUser->can('Home_Check','c') && isset($_['AlarmeUserName'])&& isset($_['AlarmePassName'])&& isset($_['AlarmeMsgName']))
			{
				$alarme_Manager = new AlarmeSMS();
				$alarme_Manager->setType($_['AlarmeTypeName']);
				$alarme_Manager->setIdentifiant_user(trim($_['AlarmeUserName']));
				$alarme_Manager->setIdentifiant_mdp(trim($_['AlarmePassName']));
				$alarme_Manager->setMessage($_['AlarmeMsgName']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_SMS();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Email':
			if($myUser->can('Home_Check','c') &&isset($_['smtpServerAddr'])&&isset($_['smtpServerPort'])&&isset($_['smtpServerSSL'])&&isset($_['smtpServerUser'])&&isset($_['smtpServerPasswd'])
				&&isset($_['EmailAddr'])&&isset($_['EmailExp'])&&isset($_['EmailOjt'])&&isset($_['EmailMsg']))
			{
				$alarme_Manager = new AlarmeEmail();
				$alarme_Manager->setSmtpServerAddr(trim($_['smtpServerAddr']));
				$alarme_Manager->setSmtpServerPort(trim($_['smtpServerPort']));
				$alarme_Manager->setSmtpServerSSL(trim($_['smtpServerSSL']));
				$alarme_Manager->setSmtpServerUser(trim($_['smtpServerUser']));
				$alarme_Manager->setSmtpServerPasswd(trim($_['smtpServerPasswd']));
				$alarme_Manager->setEmailAddr($_['EmailAddr']);
				$alarme_Manager->setEmailExp($_['EmailExp']);
				$alarme_Manager->setEmailOjt($_['EmailOjt']);
				$alarme_Manager->setEmailMsg($_['EmailMsg']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_Email();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_GPIO':
			if($myUser->can('Home_Check','c') && isset($_['descriptionGPIO'])&& isset($_['numGPIO'])&& isset($_['stateGPIO']))
			{
				$alarme_Manager = new AlarmeGPIO();
				$alarme_Manager->setDescriptionGPIO($_['descriptionGPIO']);
				$alarme_Manager->setNumGPIO(trim($_['numGPIO']));
				$alarme_Manager->setStateGPIO(trim($_['stateGPIO']));
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_GPIO();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Vocal':
			if($myUser->can('Home_Check','c') && isset($_['MessageVocal']))
			{
				$alarme_Manager = new AlarmeActionVocal();
				$alarme_Manager->setMessageVocal($_['MessageVocal']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActions_Vocales();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_CommandeVocale':
			if($myUser->can('Home_Check','c') && isset($_['type'])&& isset($_['commandeVocale']))
			{
				$alarme_Manager = new AlarmeCommandeVocale();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setCommande($_['commandeVocale']);
				$alarme_Manager->setConfidence("0.92");
				$alarme_Manager->save();
				echo plugin_alarme_LoadCommandes_Vocales();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Camera':
			if($myUser->can('Home_Check','c'))
			{
				if (isset($_['type']) && $_['type'] =="Photo")
				{
					if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
					{
						$alarme_conf = new AlarmeConf();
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
						$alarme_conf->setValue(trim($_['type']));
						$alarme_conf->save();
						
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_V']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_H']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraOption']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraCopyDirectory']));
						$alarme_conf->save();
					}
				}
				elseif((isset($_['type'])) && ($_['type'] =="Video"))
				{
					if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_TimeToCapture'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
					{	
						$alarme_conf = new AlarmeConf();
						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraType"));
						$alarme_conf->setValue(trim($_['type']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResV"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_V']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraResH"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_Resolution_H']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraTime"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_TimeToCapture']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraOption"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraOption']));
						$alarme_conf->save();

						$alarme_conf = $alarme_conf->load(array("conf"=>"Plugin_Alarme_CameraCopyDirectory"));
						$alarme_conf->setValue(trim($_['Plugin_Alarme_CameraCopyDirectory']));
						$alarme_conf->save();
					}
				}
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Enregistré';		
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur :'.$e->getMessage();
			}
		break;
		
		case 'plugin_alarme_add_URL':
			if($myUser->can('Home_Check','c') && isset($_['type'])&& isset($_['actionUrl']))
			{
				$alarme_Manager = new AlarmeURL();
				$alarme_Manager->setType($_['type']);
				$alarme_Manager->setUrl($_['actionUrl']);
				$alarme_Manager->save();
				echo plugin_alarme_LoadActionsURL();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_add_Shell':
		if($myUser->can('Home_Check','c')&& isset($_['actionShell']))
		{
			$alarme_Manager = new AlarmeShell();
			$alarme_Manager->setShell($_['actionShell']);
			$alarme_Manager->save();
			echo plugin_alarme_LoadActionsShell();
		}
		else
		{
			header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
		}
		break;
		
		//Modificaiton des refresh du widgetcase 'plugin_alarme_add_URL':
		case 'plugin_alarme_updateRefresh':
			if($myUser->can('Home_Check','u') && isset($_['champs'])&& isset($_['value']))
			{
				$alarme_conf = new AlarmeConf();
				$alarme_conf = $alarme_conf->load(array("conf"=>$_['champs']));
				$alarme_conf->setValue($_['value']);
				$alarme_conf->save();
			}
			else
			{
				header('location:setting.php?section=Home_Check&block=alarme&error=Vous n\'avez pas le droit de faire ça!');
			}
		break;
		
		case 'plugin_alarme_delete_alarme_ADSensor':
		if($myUser->can('Home_Check','d') && isset($_['id']))
		{
			$alarme_Manager = new AlarmeSensor();
			$alarme_Manager->delete(array('id'=>$_['id']));
			echo  plugin_alarme_LoadADSensor();
		}
		else
		{
			 echo 'Token ou utilisateur incorrect';
		}
		break;
		
		case 'plugin_alarme_delete_alarme_Sensor':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeSensor();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadSensor();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_SMS':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeSMS();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_SMS();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_Email':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeEmail();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_Email();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_GPIO':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeGPIO();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_GPIO();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_Vocal':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeActionVocal();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActions_Vocales();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_camera':
			if($myUser->can('Home_Check','d') && isset($_['name']))
			{
				$absolute_path = getcwd()."/plugins/Home_Check/camera/";
				unlink($absolute_path.$_['name']);
				echo  plugin_alarme_LoadCamera();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_Radio':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$HomeCheckManager = new AlarmeSensorRadio();
				
                $HomeCheckManager->delete(array('id'=>$_['id']));
				
				echo  plugin_alarme_LoadSensorRadio(array('type'=>$_['type']));
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_delete_HomeCheck':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$HomeCheckManager = new Home_Check();
                $HomeCheckManager->delete(array('id'=>$_['id']));
				
				echo  plugin_alarme_LoadPersonnes();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_alarme_CommandeVocale':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeCommandeVocale();
				$alarme_Manager->delete(array('id'=>$_['id']));
				
				echo  plugin_alarme_LoadCommandes_Vocales();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_Url':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeURL();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActionsURL();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
		
		case 'plugin_alarme_delete_Shell':
			if($myUser->can('Home_Check','d') && isset($_['id']))
			{
				$alarme_Manager = new AlarmeShell();
				$alarme_Manager->delete(array('id'=>$_['id']));
				echo  plugin_alarme_LoadActionsShell();
			}
			else
			{
				 echo 'Token ou utilisateur incorrect';
			}
		break;
			
		//fonction appelée en ajax pour tester les identifiants/pass/message
		case 'plugin_alarme_test_SMS':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['user'])&& isset($_['pass'])&& isset($_['msg']))
			{
				$user=$_['user'];
				$pass=$_['pass'];
				$msg=$_['msg'];
			}
			elseif (isset($_['id']))
			{
				$alarme_Manager = new AlarmeSMS("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$user=$alarme_Manager->getIdentifiant_user();
				$pass=$alarme_Manager->getIdentifiant_mdp();
				$msg=$alarme_Manager->getMessage();
			}
			$return =plugin_alarme_sendSms($user,$pass, $conf->get('VOCAL_ENTITY_NAME')." ".$msg);
			Switch ($return)
				{
				case "200":
					$retour ='<i class="fa fa-check fa-2x" style="color:green"></i>Sms envoyé';
				break;
				
				case "400":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Un des paramètres obligatoires est manquant.';
				break;	
				
				case "402":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Trop de SMS ont été envoyés en trop peu de temps.';
				break;	
				
				case "403":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Le service n\'est pas activé sur l\'espace abonné, ou login / clé incorrect.';
				break;	
				
				case "500":
					$retour = '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur côté serveur. Veuillez réessayer ultérieurement.';
				break;	
				
				default:
				echo curl_error($ch);
			break;
			}
			echo $retour;
		}
		break;	
		
		case 'plugin_alarme_test_Email':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['smtpServerAddr'])&&isset($_['smtpServerPort'])&&isset($_['smtpServerSSL'])&&isset($_['smtpServerUser'])&&isset($_['smtpServerPasswd'])
			&&isset($_['EmailAddr'])&&isset($_['EmailExp'])&&isset($_['EmailOjt'])&&isset($_['EmailMsg']))
			{
				$smtpServerAddr=$_['smtpServerAddr'];
				$smtpServerPort=$_['smtpServerPort'];
				$smtpServerSSL=$_['smtpServerSSL'];
				$smtpServerUser=$_['smtpServerUser'];
				$smtpServerPasswd=$_['smtpServerPasswd'];
				$EmailAddr=$_['EmailAddr'];
				$EmailExp=$_['EmailExp'];
				$EmailOjt=$_['EmailOjt'];
				$EmailMsg=$_['EmailMsg'];
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeEmail("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$smtpServerAddr=$alarme_Manager->getSmtpServerAddr();
				$smtpServerPort=$alarme_Manager->getSmtpServerPort();
				$smtpServerSSL=$alarme_Manager->getSmtpServerSSL();
				$smtpServerUser=$alarme_Manager->getSmtpServerUser();
				$smtpServerPasswd=$alarme_Manager->getSmtpServerPasswd();
				$EmailAddr=$alarme_Manager->getEmailAddr();
				$EmailExp=$alarme_Manager->getEmailExp();
				$EmailOjt=$alarme_Manager->getEmailOjt();
				$EmailMsg=$alarme_Manager->getEmailMsg();
			}
			
			try
			{
				plugin_alarme_sendEmail($smtpServerAddr,$smtpServerPort,$smtpServerSSL,$smtpServerUser,$smtpServerPasswd,$EmailAddr,$EmailExp,$EmailOjt,$EmailMsg);
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Email envoyé';
			}
			catch (Exception $e) 
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur recue :'.$e->getMessage();
			}
		}
		break;
		
		//fonction appelée en ajax pour tester les identifiants/pass/message
		case 'plugin_alarme_test_GPIO':
			
			if($myUser->can('Home_Check',"r"))
			{
				if(isset($_['numGPIO'])&& isset($_['stateGPIO']))
				{
					$numGPIO=(int)$_['numGPIO'];
					$stateGPIO=(int)$_['stateGPIO'];
				}
				elseif (isset($_['id']))
				{
					$alarme_Manager = new AlarmeGPIO("r");
					$alarme_Manager=$alarme_Manager->getById($_['id']);
					$numGPIO=(int)$alarme_Manager->getNumGPIO();
					$stateGPIO=(int)$alarme_Manager->getStateGPIO();
				}
				
				//Si l'etat demandé est le méme que le test, on change l'etat avant le test pour valider le fonctionnement
				$preState=(int)Gpio::read($numGPIO);
				Gpio::mode($numGPIO,'out');
				$ChangePrea=$preState;
				if ($preState==$stateGPIO)
				{
					$at = $preState == 1 ? 0 : 1;
					Gpio::write($numGPIO,$at);
					
					$ChangePrea=(int)Gpio::read($numGPIO);
					if ($ChangePrea!=$preState)
					{
						echo '<i class="fa fa-check fa-2x" style="color:green"></i>Changement préalable de la sortie pour validation du changement ok</br>';
					}
					else
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Changement préalable de la sortie pour validation du changement échoué</br>';
					}
				}
				
				//On change l'état
				Gpio::mode($numGPIO,'out');
				Gpio::write($numGPIO,$stateGPIO);
				
				//On vérifie
				$postState=(int)Gpio::read($numGPIO);
				
				//On confirme ou non
				if(($stateGPIO==$postState&&$preState!=$stateGPIO)||($stateGPIO==$postState&&$ChangePrea!=$stateGPIO))
				{
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>Changement GPIO validé';
				}
				else
				{
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Echec lors du changement';
				}
				
				//On met le pin dans son état précédant
				Gpio::mode($numGPIO,'out');
				Gpio::write($numGPIO,$preState);
				
				//Re-test de la reprise de l'etat précédant
				
			}
		break;
		
		case 'plugin_alarme_test_Camera':
		if($myUser->can('Home_Check',"r"))
		{	
				$alarme_conf = new AlarmeConf("r");
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_CameraDirectory"));
				$absolute_path=$alarme_conf->getValue();
			if (isset($_['type']) && $_['type'] =="Photo")
			{
				if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
				{
					try
					{
						$name =time().".jpg";
						system('raspistill '.$_['Plugin_Alarme_CameraOption'].' -w '.$_['Plugin_Alarme_Resolution_V'].' -h '.$_['Plugin_Alarme_Resolution_H'].'-n -o '.$absolute_path.$name);
						//Si le champs copie n'est pas vide, on copi la photo ou la vidéo.
						if ($_['Plugin_Alarme_CameraCopyDirectory']!="")
						{
							copy($absolute_path.$name, $_['Plugin_Alarme_CameraCopyDirectory'].$name);
						}
						echo plugin_alarme_LoadCamera();
					}
					catch (Exception $e) 
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Erreur lors de la capture, erreur : '.$e->getMessage().'<br>';
					}
				}
			}	
			elseif((isset($_['type'])) && ($_['type'] =="Video"))
			{
				if(isset($_['Plugin_Alarme_Resolution_H'])&&isset($_['Plugin_Alarme_Resolution_V'])&&isset($_['Plugin_Alarme_TimeToCapture'])&&isset($_['Plugin_Alarme_CameraOption'])&&isset($_['Plugin_Alarme_CameraCopyDirectory']))
				{	
					try
					{
						$name =time();
						system('raspivid '.$_['Plugin_Alarme_CameraOption'].' -t '.$_['Plugin_Alarme_TimeToCapture'].' -w '.$_['Plugin_Alarme_Resolution_V'].' -h '.$_['Plugin_Alarme_Resolution_H'].' -n -o '.$absolute_path.$name.'.h264');
						system('MP4Box -fps 30 -add '.$absolute_path.$name.'.h264 '.$absolute_path.$name.'.mp4 > /dev/null');
						unlink($absolute_path.$name.'.h264');
						//Si le champs copie n'est pas vide, on copi la photo ou la vidéo.
						if ($_['Plugin_Alarme_CameraCopyDirectory']!="")
						{
							copy($absolute_path.$name.'.mp4', $_['Plugin_Alarme_CameraCopyDirectory'].$name.'.mp4');
						}
						
						echo plugin_alarme_LoadCamera();
					}
					catch (Exception $e) 
					{
						echo '<i class="fa fa-times fa-2x" style="color:red"></i> Erreur lors de la capture, erreur : '.$e->getMessage().'<br>';
					}
				}
			}
		}
		break;
		
		case 'plugin_alarme_test_Vocal':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['MessageVocal']))
			{
				$MessageVocal=$_['MessageVocal'];
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeActionVocal("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$MessageVocal=$alarme_Manager->getMessageVocal();
			}
			
			try
			{
				$cli = new Client();
				$cli->connect();
				$cli->talk(htmlspecialchars_decode($MessageVocal,ENT_QUOTES));
				$cli->disconnect();
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Diction ok';
			}
			catch (Exception $e) 
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de la disction de la phrase : '.$alarme_Manager->getMessageVocal().', erreur : '.$e->getMessage().'<br>';
			}

		}
		break;
				
		case 'plugin_alarme_test_URL':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['actionUrl']))
			{
				$url=urldecode($_['actionUrl']);
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeURL("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$url=htmlspecialchars_decode($alarme_Manager->getUrl(),ENT_QUOTES);
			}
			if (function_exists('curl_version'))
			{
				//Si CURL est activé, tester l'URL
				$ch = curl_init();
				curl_setopt($ch,CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_TIMEOUT, 5);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				if(curl_exec($ch))
				{
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>URL exécutée<br>';
					echo '<i class="fa fa-check fa-2x" style="color:green"></i>Retour de l\'URL :'.curl_multi_getcontent($ch);
				}
				else
				{
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de l\'exécution de l\'URL : '.curl_error($ch).'<br>';
					echo '<i class="fa fa-times fa-2x" style="color:red"></i>Code d\'erreur HTML: '.curl_getinfo($ch, CURLINFO_HTTP_CODE);
				}
				curl_close($ch);
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Impossible de tester l\'URL de Yana-Server, cURL manquant sur ce RPI';
			}
		}
		break;
		
		case 'plugin_alarme_test_Shell':
		if($myUser->can('Home_Check',"r"))
		{
			if(isset($_['actionShell']))
			{
				$Shell=urldecode($_['actionShell']);
			}
			elseif(isset($_['id']))
			{
				$alarme_Manager = new AlarmeShell("r");
				$alarme_Manager=$alarme_Manager->getById($_['id']);
				$Shell=htmlspecialchars_decode($alarme_Manager->getShell(),ENT_QUOTES);
			}
			$return2 = exec($Shell, $returnString, $returnState);
			
			if (!$returnState)
			{	
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Commande Shell : "'.$Shell.'" exécutée avec succés <br>';
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Retour du Shell : ';
				print_r($returnString);
			}
			else
			{
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Erreur lors de l\'exécution de la commande : "'.$Shell.'"<br>';
				echo '<i class="fa fa-times fa-2x" style="color:red"></i>Retour du Shell: ';
				print_r($returnString);
			}
			
		}
		break;
		
		case 'plugin_alarme_timetoStart':
		if($myUser->can('Home_Check','c'))
		{
			if(isset($_['time']))
			{
				$alarme_conf = new AlarmeConf();
				$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_timetoStart"));
				$alarme_conf->setValue($_['time']);
				$alarme_conf->save();  
				echo '<i class="fa fa-check fa-2x" style="color:green"></i>Enregistré';
			}
		}
		break;
		
		case 'plugin_alarme_doc_install':
		if($myUser->can('Home_Check','c'))
		{
			header("Content-type:application/pdf");
			header("Content-Disposition:attachment;filename='InstallationPluginAlarme.pdf'");
			readfile("InstallationPluginAlarme.pdf");
		}
		break;
				
		case 'ponctuel_alarme':

		//$table1 = new AlarmeShell();
		//$table1->create();
		
		//$alarme_conf = new AlarmeConf("r");
		//$objetCharge=$alarme_conf->load(array("conf"=>"plugin_alarme_RefreshWidget"));
		//$objetCharge->setValue("9000");
		//$objetCharge->save(); 
			//global $myUser, $conf;
			//print_r ($_SESSION['configuration']);
		break;
	
		//Widget
		case 'plugin_alarme_load_widget':
			
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{		
				$alarme_manager = new AlarmeConf("r");
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_Start"));
				$plugin_alarme_Start=$alarme_conf->getValue();
				
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_RefreshWidget"));				
				$plugin_alarme_RefreshWidget=$alarme_conf->getValue();
				
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_RefreshWidgetPhoto"));				
				$plugin_alarme_RefreshWidget_photo=$alarme_conf->getValue();
				
				header('Content-type: application/json');				
				$response = array();
				$response['title'] = "Alarme";
				$response['content'] = '<script type="text/javascript" src="./plugins/Home_Check/js/widget.js"></script>
				<div id="xhrBlock">';
				
				$response['content'] .='<div id="widget_plugin_alarme_valeur_id" data-valeur="'.$plugin_alarme_Start.'" data-refresh="'.$plugin_alarme_RefreshWidget.'" ><a class="btn" title="Activé désactiver l\'alarme"> ';
				$response['content'] .='<i id="widget_plugin_alarme_icone_id" class=" fa fa-cog fa-lg" style="color:black" ></i></a><span id="widget_plugin_alarme_sentence_id"></span>';
				$response['content'] .='</div></div>';
				//prise de photo ou video
				$response['content'] .='<div data-photoexist="1" data-refreshphoto="'.$plugin_alarme_RefreshWidget_photo.'" id="xhrBlockPhoto" ><img id="widget_plugin_alarme_photo_id" style="max-width:631px;margin:auto;width:100%;height:auto;display: none;" ></div>';
				
				echo json_encode($response);
				
			}
		break;
		
		case 'plugin_alarme_load_widget_refresh':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				echo plugin_alarme_LoadWidget();
			}
		break;
		
		case 'plugin_alarme_load_widget_refresh_photo':
			if(!$myUser->can('Home_Check',"r")) exit('Token ou utilisateur incorrect');
			{
				$alarme_manager = new AlarmeConf("r");
				$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_WidgetCameraOption"));				
				$plugin_alarme_WidgetCameraOption=$alarme_conf->getValue();
			
				//On supprime les photos existantes
				array_map('unlink', glob(getcwd()."/plugins/Home_Check/cameraWidget/*.jpg"));
				
				//on prend la novuelle
				$absolute_path =getcwd()."/plugins/Home_Check/cameraWidget/";
				$name=time().".jpg";
				
				exec('raspistill '.$plugin_alarme_WidgetCameraOption.' -w 631 -h 631 -n -o '.$absolute_path.$name, $output, $return);

				if($return==0)
				{
					$valeur="1";
					$sentence=" Caméra disponible";
				}
				else
				{
					$valeur="0";
					$sentence=" Camera non dispopnible pour la prise de photo";	

				}
				
				$refresh=array(	"valeur"=>$valeur,
				"sentence"=>$sentence,
				"chemin"=>"./plugins/Home_Check/cameraWidget/".$name,
				"error"=>$error);
				echo json_encode($refresh);
			}
		break;
		
		case 'plugin_alarme_click_toChangeAlarme':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
			if (isset($_['state']))
				{
					if ($_['state']=="1")
					{
						$error = Plugin_Alarme_Desactivation();
					}
					elseif($_['state']=="0")
					{
						$error = plugin_alarme_Activation();
					}
					elseif($_['state']=="2")
					{
						$error = $error = Plugin_Alarme_Desactivation();
					}
					echo plugin_alarme_LoadWidget($error);
				}
		break;
		
		//Fonction appelée par les widgets pour choisir une couleur pour le widget
		case 'plugin_alarme_click_change_color':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
				echo '<form name="mon_formulaire">
				<input type="color" id ="plugin_alarme_changeColor" name="plugin_alarme_changeColor" />
				<br />
				<input type="button" value="Enregistrer" onclick="plugin_alarme_saveColor()" />
				</form>';
		break;

		case 'plugin_alarme_click_save_color':
			if(!$myUser->can('Home_Check','u')) exit('Token ou utilisateur incorrect');
				if (isset($_['color']))
				{
					$alarme_manager = new AlarmeConf();
					$alarme_conf = $alarme_manager->load(array("conf"=>"plugin_alarme_widget_color"));
					$alarme_conf->setValue($_['color']);
					$alarme_conf->save();
					header('location:index.php');
				}
		break;
		
		case 'HomeCheck_import_HomeCheck':
            Action::write(
                function ($_, &$response) {
                    $exportprofiles = json_decode($_POST["import"]);
                    //var_dump($exportRadios);
                    if ($exportprofiles) {
                        foreach ($exportprofiles as $exportprofile) {
                                 $homecheck = new Home_Check();
                                 $homecheck->name = $exportprofile->name;
                                 $homecheck->description = $exportprofile->description;
                                 $homecheck->imei = $exportprofile->imei;
								 $homecheck->state="0";
                                 $homecheck->isadmin = $exportprofile->isadmin;
                                 $homecheck->password = $exportprofile->password;
								 $homecheck->nummobile = $exportprofile->nummobile;
								 $homecheck->email = $exportprofile->email;
								 $homecheck->ip = "";
								 $homecheck->location = "";
								 $homecheck->isclientserv = $exportprofile->isclientserv;
                                 $homecheck->save();
                                 $response['message'] = 'Relais importés avec succès';
                        }
                    } else {
                        throw new Exception("Les valeurs importés sont incorrectes, vérifier les dans un lecteur JSON");
                    }
                },
                array('plugin_HomeCheck'=>'c')
            );
            break;
	}
}
function plugin_alarme_LoadADSensor()
{
	global $myUser;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSensor("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorADGPIO'));
		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Numéro du GPIO</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getDescription(); ?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getNumGPIO(); 
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_ADSensor(<?php echo $alarme->getId(); ?>);" title="Supprimer ce détecteur"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}

function plugin_alarme_LoadSensorRadio($type)
{
	global $myUser;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSensorRadio("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>$type));
		if ($type=="SensorTXRADIO") 
		{
			$ssbloc="SensorTXRADIO";
		}
		else {
			$ssbloc="SensorRXRADIO";
		}

		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Code ON</th>
					<th width=100>Code OFF</th>
					<?php if ($ssbloc==SensorRXRADIO) { ?>
					<th width=100>Commande vocale ON</th>
					<th width=100>Commande vocale OFF</th>
					<?php } ?>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td><?php echo $alarme->getDescription(); ?></td>
					<td width=100><?php echo $alarme->radiocodeOn;?></td>
					<td width=100><?php echo $alarme->radiocodeOff;?></td>
					<?php if ($ssbloc==SensorRXRADIO) { ?>
					<td width=100><?php echo $alarme->onCommand;?></td>
					<td width=100><?php echo $alarme->offCommand;?></td>
					<?php } ?>
					<td>
						<a class="btn" href="setting.php?section=Home_Check&block=Sensor&sousblock=<?php echo $ssbloc?>&id=<?php echo $alarme->id; ?>">
							<i class="fa fa-pencil"></i>
						</a>
						<div class="btn" onclick="plugin_HomeCheck_RadioDelete(<?php echo $alarme->id; ?>,this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</tr>
				<?php
			}
			$exportRadios = $alarmes;
			foreach ($exportRadios as $key => $exportRadio) {
				unset($exportRadios[$key]->id);
				unset($exportRadios[$key]->state);
				}
			 ?>
             </table>
               
			<legend>Exporter vos relais existants</legend>
			<textarea cols="100" ><?php echo json_encode($exportRadios); ?></textarea>
			
			<legend>Importer de nouveaux relais </legend>
			<div class="import">
			<textarea id="import" name="import" cols="100" ></textarea>
			
					<button onclick="plugin_genericradio_import(this)" class="btn">Importer</button>
			</div>
			</div>

		<?php
	}
}


function plugin_alarme_LoadSensor()
{
	global $myUser;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSensor("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'SensorGPIO'));
		?>
			<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description détecteur</th>
					<th width=100>Numéro du GPIO</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getDescription(); ?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getNumGPIO(); 
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Sensor(<?php echo $alarme->getId(); ?>);" title="Supprimer ce détecteur"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}

function plugin_alarme_LoadActions_SMS()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeSMS("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Type d'alarme</th>
					<th>Utilisateur</th>
					<th>Mot de passe</th>
					<th>Message</th>
					<th>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getType(); ?>
					</td>
					<td>
						<?php
							echo $alarme->getIdentifiant_user(); 
						?>
					</td>
					<td>
						<?php
							echo str_repeat("*", strlen($alarme->getIdentifiant_mdp()));
						?>
					</td>
					<td>
						<?php
							echo htmlspecialchars_decode($alarme->getMessage(),ENT_QUOTES);
						?>
					</td>
					<td width=50>
						<a class="btn btn-success" onclick="plugin_alarme_test_SMS_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester l'envoie de SMS"  ><i class="fa fa-refresh" id ="plugin_alarme_test_sms<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_SMS(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}	
}

function plugin_alarme_LoadActions_Email()
{
	global $myUser,$_;
	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeEmail("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Messagerie (Adresse serveur, Port, Ssl, Utilisateur, Mdp)</th>
					<th>Email (Adresse destinataire,Nom expéditeur, Objet, Message)</th>
					<th>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getSmtpServerAddr(); ?>
						<br/>
						<?php echo $alarme->getSmtpServerPort(); ?>
						<br/>
						<?php echo $alarme->getSmtpServerSSL(); ?>
						<br/>
						<?php echo $alarme->getSmtpServerUser(); ?>
						<br/>
						
						<?php echo str_repeat("*", strlen($alarme->getSmtpServerPasswd())); ?>
					</td>
					<td>
						<?php echo $alarme->getEmailAddr(); ?>
						<br/>
						<?php echo $alarme->getEmailExp(); ?>
						<br/>
						<?php echo $alarme->getEmailOjt(); ?>
						<br/>
						<?php echo $alarme->getEmailMsg(); ?>
					</td>
					<td width=50>
						<a class="btn btn-success" onclick="plugin_alarme_test_Email_ponctuel(<?php echo $alarme->getId(); ?>);
						" title="Tester l'envoie d'Email"  ><i class="fa fa-refresh" id ="plugin_alarme_test_email<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php 
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Email(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}

function plugin_alarme_LoadActions_GPIO()
{
	global $myUser,$_;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeGPIO("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th>Description GPIO</th>
					<th width=100>Numéro du GPIO</th>
					<th width=100>Etat du GPIO lors d'une alerte</th>
					<th width=100>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getDescriptionGPIO(); ?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getNumGPIO(); 
						?>
					</td>
					<td width=100>
						<?php
							echo $alarme->getStateGPIO();
						?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_GPIO_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester le changement d'état d'un GPIO endant 3 secondes"  ><i class="fa fa-refresh" id ="plugin_alarme_test_gpio<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_GPIO(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}
	
function plugin_alarme_LoadActions_Vocales()
{
	global $myUser,$_;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeActionVocal("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=150>Message</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ ?>
				<tr>
					<td>
						<?php echo $alarme->getMessageVocal(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_Vocal_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester la diction de cette phrase"  ><i class="fa fa-refresh" id ="plugin_alarme_test_Vocal<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_Vocal(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  ?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadCamera()
{
	global $myUser;

	if($myUser!=false)
	{		
		$alarme_conf = new AlarmeConf("r");
		$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_CameraDirectory"));
		$dir=$alarme_conf->getValue();

		$ScanDir=scandir($dir, 1);
		foreach($ScanDir as $value) 
		{ 
			// on exclue les fichier system, et on filtre seulement les images Jpg et les videos mp4
			if($value === '.' || $value === '..') {continue;}
			elseif(strstr($value ,'.jpg')!=false)
			{
				echo '<div style="position: relative;">';
				echo '<span style="position:absolute; top: 5px; left: 5px; z-index: 100;" ><a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_camera(\''.$value.'\');" title="Supprimer cette photo"><i class="fa fa-times" style="color:white" ></i></a></span>';
				echo '<img class="img-polaroid img-rounded" src="plugins/Home_Check/camera/'.$value.'" ><br/>';
				echo '</div>';
			}
			elseif((strstr($value ,'.mp4')!=false))
			{
				echo '<div style="position: relative;">';
				echo '<span style="position:absolute; top: 5px; left: 5px; z-index: 100;" ><a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_camera(\''.$value.'\');" title="Supprimer cette photo"><i class="fa fa-times" style="color:white" ></i></a></span>';
				echo '<video controls="controls" type="video/mp4" src="plugins/Home_Check/camera/'.$value.'">Vous n\'avez pas de navigateur moderne, donc pas de balise video HTML5 !</video>';
				echo '</div>';
			}
		}
	}
}

function plugin_alarme_LoadPersonnes()
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$People_Manager = new Home_Check("r");
		$Home_Checks = $People_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Nom</th>
					<th width=200>Admin</th>
					<th width=100>Présente</th>
					<th width=200>Console</th> 							
				</tr>
			</thead>
			
			<?php 
			
				foreach ($Home_Checks as $HomeCheck) {
				?>
				<tr>
					<td><?php echo $HomeCheck->name; ?></td>
					<td><?php echo $HomeCheck->isadmin; ?></td>
					<td><?php echo $HomeCheck->state; ?></td>
					<td><?php echo $HomeCheck->isclientserv; ?></td>
					<td width=50>
						<a class="btn" href="setting.php?section=Home_Check&block=ADAlarme&sousblock=AlarmeGeneral&id=<?php echo $HomeCheck->id; ?>">
							<i class="fa fa-pencil"></i>
						</a>
						<div class="btn" onclick="plugin_HomeCheck_delete(<?php echo $HomeCheck->id; ?>,this);">
							<i class="fa fa-times"></i>
						</div>
					</td>
				</td>
			</tr>
			<?php
			}
			$exportRadios = $Home_Checks;
			foreach ($exportRadios as $key => $exportRadio) {
				unset($exportRadios[$key]->id);
				unset($exportRadios[$key]->state);
			}
			?>
		</table>
		
		
		<legend>Exporter vos profiles</legend>
		<textarea cols="1000" ><?php echo json_encode($Home_Checks); ?></textarea>
		
		<legend>Importer de nouvelles personnes </legend>
		<div class="import">
		<textarea id="import" name="import" cols="100" ></textarea>
				<button onclick="plugin_HomeCheck_import(this)" class="btn">Importer</button>
		</div>

		<?php
	}
}

function plugin_alarme_LoadCommandes_Vocales()
{
	global $myUser,$conf;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeCommandeVocale("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=50>Type</th>
					<th width=200>Commande</th>
					<th width=100>Confidence</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getType(); ?>
					</td>
					<td>
						<?php echo $conf->get('VOCAL_ENTITY_NAME').' : '.$alarme->getCommande(); ?>
					</td>
					<td>
						<?php echo $alarme->getConfidence(); ?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_alarme_CommandeVocale(<?php echo $alarme->getId(); ?>);" title="Supprimer cette alarme"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadActionsURL()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeURL("r");
		$alarmes = $alarme_Manager->loadAll(array('type'=>'ActionUrl'));
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=200>URL</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getUrl(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_actionsUrl_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester cette URL"  ><i class="fa fa-refresh" id ="plugin_alarme_test_actionsUrl<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						 <br>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_Url(<?php echo $alarme->getId(); ?>);" title="Supprimer cette URL"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadActionsShell()
{
	global $myUser;

	if($myUser!=false)
	{
		$alarme_Manager = new AlarmeShell("r");
		$alarmes = $alarme_Manager->populate();
		?>
		<table class="table table-striped table-bordered table-hover">
			<thead>
				<tr>
					<th width=200>Shell</th>
					<th width=150>Tester</th>
					<th width=50>Suppression</th>
				</tr>
			</thead>

			<?php 
			foreach($alarmes as $alarme)
			{ 
				?>
				<tr>
					<td>
						<?php echo $alarme->getShell(); ?>
					</td>
					<td width=100>
						<a class="btn btn-success" onclick="plugin_alarme_test_actionsShell_ponctuel(<?php echo '\''.$alarme->getId().'\''; ?>);"
						 title="Tester cette commande"  ><i class="fa fa-refresh" id ="plugin_alarme_test_actionsShell<?php echo $alarme->getId(); ?>" style="color:white" ></i></a>
						 <br>
						<?php
						echo '<span id="plugin_alarme_test_spanId'.$alarme->getId().'" style="display:none;"></span>';
						?>
					</td>
					<td width=50>
					<a class="btn btn-danger" onclick="plugin_alarme_delete_Shell(<?php echo $alarme->getId(); ?>);" title="Supprimer cette commande"><i class="fa fa-times" style="color:white" ></i></a>
					</td>
				</tr>
				<?php 
			}  
			?>
		</table>
		<?php
	}
}	

function plugin_alarme_LoadWidget($error=null) {
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));
	if($alarme_conf->getValue()=="1")
	{
		$sentence=" Alarme activée, surveillance en cours";
	}
	elseif($alarme_conf->getValue()=="0")
	{
		$sentence=" Alarme désactivée";
	}
	elseif($alarme_conf->getValue()=="2")
	{
		$sentence=" Alarme déclenchée, surveillance en cours";
	}
	$refresh=array(	"valeur"=>$alarme_conf->getValue(),
						"sentence"=>$sentence,
						"error"=>$error);
	echo json_encode($refresh);
}


function plugin_alarme_widget(&$widgets){
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_widget_color"));
	
	$widgets[] = array(
		'uid'      => 'dash_plugin_alarme',
		'icon'     => 'fa fa-bell-o',
		'label'    => 'Plugin Alarme',
		'addToHead'=> '	<li style="color:white" onclick="plugin_alarme_changeColor()"><i class="fa fa-adjust"></i></li>',
		'background' => $alarme_conf->getValue(), 
		'color' => '#fffffff',
		'onLoad'   => 'action.php?action=plugin_alarme_load_widget',
		'onEdit'   => 'action.php?action=plugin_alarme_edit_widget',
		'onSave'   => 'action.php?action=plugin_alarme_save_widget',
	);
}

function HomeCheck_alarmStatus() {
	
	$alarme_conf = new AlarmeConf("r");
	$alarme_conf = $alarme_conf->load(array("conf"=>"plugin_alarme_Start"));				
	$status=$alarme_conf->getValue();
	
	return $status;	
	
}

function HomeCheck_SetLocalIP($ip,$imei) {
	
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$HomeCheck->ip=$ip;
			$HomeCheck->save();
			return $HomeCheck->isclientserv;
			break;
		}
	}
}

function HomeCheck_SetPos($pos,$imei) {
	
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$HomeCheck->location=$pos;
			$HomeCheck->save();
			break;
		}
	}	
}

function HomeCheck_whoisadmin($imei) {
	
	$code='';
	$gtr=0;
	
	$HomeCheckManager = new Home_Check();
	$HomeChecks = $HomeCheckManager->populate();
	
	foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
			$code=$HomeCheck->isadmin.'_'.$HomeCheck->password.'_'.$HomeCheck->nummobile;
			break;
		}
	}
	
    foreach ($HomeChecks as $HomeCheck) {
		//echo $HomeCheck->state."<br>";
		if ($HomeCheck->isadmin==1 && $gtr==0) {
			$gtr=1;
			$code=$code.'_'.$HomeCheck->password.'_'.$HomeCheck->nummobile.'_'.$HomeCheck->email;
		}
	}
	
	return $code;	
}

function HomeCheck_whois($check) {
	$HomeCheckManager = new Home_Check();
	$code='';
    $HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		//echo $HomeCheck->state."<br>";
		
		if ($HomeCheck->state==1) {
			if ($check==0) {
			$code=$code.$HomeCheck->name.',';
			}
			else {
				$code=$code+1;
			}
		}
	}
	if ($code=='') {
		if ($check==1) {
			$code=0;}
		else {
			$code='Personne';
		}
	}
	return $code;	
}

function HomeCheck_plugin_update_state($imei,$state) {
	$HomeCheckManager = new Home_Check();
	$code='';
    $HomeChecks = $HomeCheckManager->populate();
    foreach ($HomeChecks as $HomeCheck) {
		if ($HomeCheck->imei==$imei) {
				$HomeCheck->state=$state;
				$HomeCheck->save();
				break;
		}
	}
}

function HomeCheckradio_plugin_change_state($engine, $state)
{
    global $conf;
    $genericRadio = new AlarmeSensorRadio();
    $genericRadio = $genericRadio->getById($engine);

    if ($state) {
        $code = $genericRadio->radiocodeOn;
    } else {
        $code = $genericRadio->radiocodeOff;
    }

    //If emitter not defined put it to default
    if ($conf->get('plugin_genericRadio_emitter_pin') == "") {
        $conf->put('plugin_genericRadio_emitter_pin', 0);
    }

	$param='/codesend';

    $cmd = dirname(__FILE__).$param." ".$code;
    $genericRadio->state = $state;
    Functions::log('Launch system command : '.$cmd);
    exec($cmd, $out, $err);
	
    if ($err == 0) {
       // $error = implode(" ", $out);
    } else {
        if ($err == 126) {
            $error = "Yana n'a pas le droit d'exécuter la commande";
        } else {
            $error = $code." n'est pas un code correcte";
        }
    }

	echo $error;
    $genericRadio->save();

    return $error;
}

		//Le JS
		Plugin::addJs('/js/main.js',true);
		//Le CSS
		Plugin::addCss('/css/style.css',true);
		
		//Configuration Préférence
		Plugin::addHook("setting_bloc", "plugin_alarme_setting_page"); 
		Plugin::addHook("setting_menu", "plugin_alarme_setting_menu");
		Plugin::addHook("vocal_command", "plugin_alarme_vocal_command");
		Plugin::addHook("action_post_case", "plugin_alarme_action"); 
		Plugin::addHook("widgets", "plugin_alarme_widget");

		
?>


/*
	Switchi V1.0
	@author Alex Rault
	@mail alex.rault.@laposte.net
	@licence CC-by-nc-sa
	JS pour les widget
*/
function plugin_alarme_chargement(blockId)
{
document.getElementById(blockId).innerHTML = "<div><img src=\"./plugins/alarme/img/preloader.gif\"  alt=\"Chargement\"></div>";
};


//refresh
$(function(){
setTimeout(plugin_alarme_refresh, 500);
});
//refresh
$(function(){
setTimeout(plugin_alarme_refresh_photo, 1000);
});

function plugin_alarme_refresh(){
$.ajax ({
        type: "POST",
        url:"action.php",
        data: {
		action:'plugin_alarme_load_widget_refresh'},
		dataType : 'html',
        success: function(results) {
			var obj = jQuery.parseJSON(results);
			if(obj.valeur=="1"){
				$('#widget_plugin_alarme_icone_id').addClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "green" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
			}
			else if(obj.valeur=="0")
			{
				$('#widget_plugin_alarme_icone_id').removeClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "#778899" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
			}
				else if(obj.valeur=="2")
			{
				$('#widget_plugin_alarme_icone_id').addClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "#FF8C00" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
			}
        }
    });
	setTimeout(plugin_alarme_refresh, $('#widget_plugin_alarme_valeur_id').data( "refresh"))
};

function plugin_alarme_refresh_photo(){
//Si le block photo existe, si l'alarme est activé	
	if (($('#xhrBlockPhoto').data( "photoexist")=="1"))
	{
		$.ajax ({
		type: "POST",
		url:"action.php",
		data: {
		action:'plugin_alarme_load_widget_refresh_photo'},
		dataType : 'html',
			success: function(results) {
				var obj = jQuery.parseJSON(results);
				if(obj.valeur=="1"){
					$('#xhrBlockPhoto').data( "photoexist", "1" );
					$('#widget_plugin_alarme_photo_id').show();
					$('#widget_plugin_alarme_photo_id').attr({src:obj.chemin,title: obj.sentence, height:"288px", width:"288px"});
				}
				else if(obj.valeur=="0"){
					$('#xhrBlockPhoto').data( "photoexist", "0" );
					$('#widget_plugin_alarme_photo_id').hide();
				}
				else if(obj.valeur=="2"){
					$('#xhrBlockPhoto').data( "photoexist", "1" );
					$('#widget_plugin_alarme_photo_id').show();
					$('#widget_plugin_alarme_photo_id').attr({src:obj.chemin,title: obj.sentence, height:"288px", width:"288px"});
				}
			}
		});
	}
	else //si la caméra n'est pas installé, ou l'alarme non activé, on supprimme l'image.
	{
		$('#widget_plugin_alarme_photo_id').hide();
		$('#widget_plugin_alarme_photo_id').removeAttr('src title height width');
	}
		setTimeout(plugin_alarme_refresh_photo, $('#xhrBlockPhoto').data( "refreshphoto"))
};

function plugin_alarme_changeColor(){
$("#xhrBlock").load("action.php",{
	action:"plugin_alarme_click_change_color",
	});
};

function plugin_alarme_saveColor() {
$("#xhrBlock").load("action.php",{
	action:"plugin_alarme_click_save_color",
	color:$('#plugin_alarme_changeColor').val()
	});
	window.location.reload();
};

function plugin_alarme_Activation(state) {
	$.ajax ({
        type: "POST",
        url:"action.php",
        data: {
			action:'plugin_alarme_click_toChangeAlarme',
			state:state
		},
		dataType : 'html',
        success: function(results) {
			var obj = jQuery.parseJSON(results);
			if(obj.valeur=="1"){
				$('#widget_plugin_alarme_icone_id').addClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "green" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
				//$('#widget_plugin_alarme_sentence_id').attr( "title", obj.error );
				
			}
			else if(obj.valeur=="0"){
				$('#widget_plugin_alarme_icone_id').removeClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "#778899" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
				//$('#widget_plugin_alarme_sentence_id').attr( "title", obj.error );
			}
			else if(obj.valeur=="2"){
				$('#widget_plugin_alarme_icone_id').addClass(' fa-spin');
				$('#widget_plugin_alarme_icone_id').css( "color", "#FF8C00" );
				$('#widget_plugin_alarme_sentence_id').text(obj.sentence);
				$('#widget_plugin_alarme_valeur_id').data( "valeur", obj.valeur );
				//$('#widget_plugin_alarme_sentence_id').attr( "title", obj.error );
			}
        }
    });
};

$(function(){
	$('#widget_plugin_alarme_valeur_id').click(function() {
		plugin_alarme_Activation($(this).data("valeur"));
	});
});

$(document).ready(function(){



});

function plugin_alarme_chargement(blockId)
{
	document.getElementById(blockId).innerHTML = "<img src=\"./plugins/Home_Check/img/preloader.gif\" align=\"middle\" alt=\"Chargement\"></img>";
}

//Onglet Alarme>General
$(function(){
	$('#plugin_alarme_doc_install').click(function() {
		plugin_alarme_addCommande_VocaleOn();
	});
});

//Onglet Alarme>Commandes Vocales
function plugin_alarme_addCommande_VocaleOn()
{
	if ($('#CommandeVocaleOn').val()=="")
	{
		alert ('Le champ Commande Vocale d\'activation de l\'alarme est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_CommandeVocale',
		type:'On',
		commandeVocale:$('#CommandeVocaleOn').val()
		}, function() {
		$('#CommandeVocaleOn').val('');
	});
};

$(function(){
	$('#submitAlarme_AddCommandes_VocaleOn').click(function() {
		plugin_alarme_addCommande_VocaleOn();
	});
});

function plugin_alarme_addCommande_VocaleOff()
{
	if ($('#CommandeVocaleOff').val()=="")
	{
		alert ('Le champ Commande Vocale d\'arrét de l\'alarme est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_CommandeVocale',
		type:'Off',
		commandeVocale:$('#CommandeVocaleOff').val()
		}, function() {
		$('#CommandeVocaleOff').val('');
	});
};

$(function(){
	$('#plugin_alarme_addCommande_VocaleOff').click(function() {
		plugin_alarme_addCommande_VocaleOff();
	});
});

function plugin_AddHomeCheck()
{
	if ($('#nameHomeCheck').val()=="")
	{
		alert ('Le champ nom est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_save_HomeCheck',
		nameHomeCheck:$('#nameHomeCheck').val(),
		descriptionHomeCheck:$('#descriptionHomeCheck').val(),
		IMEIHomeCheck:$('#IMEIHomeCheck').val(),
		ISADMINHomeCheck:$('#ISADMINHomeCheck').val(),
		PASSHomeCheck:$('#PASSHomeCheck').val(),
		MobileHomeCheck:$('#MobileHomeCheck').val(),
		EmailHomeCheck:$('#EmailHomeCheck').val(),
		IsClientServHomeCheck:$('#IsClientServHomeCheck').val()
		}, function() {
		$('#nameHomeCheck').val('');
		$('#descriptionHomeCheck').val();
		$('#IMEIHomeCheck').val();
		$('#ISADMINHomeCheck').val();
		$('#PASSHomeCheck').val();
		$('#MobileHomeCheck').val();
		$('#EmailHomeCheck').val();
		$('#IsClientServHomeCheck').val();
	});
};

$(function(){
	$('#plugin_AddHomeCheck').click(function() {
		plugin_AddHomeCheck();
	});
});


//Onglet AlarmeAD>GPIO
function plugin_alarme_addADSensor()
{
	if ($('#descriptionADGPIO').val()=="")
	{
		alert ("Le Description du détecteur est vide");
		return false;
	}
		
	if ($('#numADGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Sensor',
		type:$('#SensorType').val(),
		descriptionSensor:$('#descriptionADGPIO').val(),
		numGPIO:$('#numADGPIO').val()
		}, function() {
		$('#descriptionADGPIO').val('');
		$('#numADGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddADSensor').click(function() {
		plugin_alarme_addADSensor();
	});
});

function plugin_alarme_delete_alarme_ADSensor(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_ADSensor',
	id:id
	});
};

//Onglet Detecteur>GPIO

function plugin_alarme_addSensor()
{
	if ($('#descriptionSensor').val()=="")
	{
		alert ("Le Description du détecteur est vide");
		return false;
	}
		
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Sensor',
		type:$('#SensorType').val(),
		descriptionSensor:$('#descriptionSensor').val(),
		numGPIO:$('#numGPIO').val()
		}, function() {
		$('#descriptionSensor').val('');
		$('#numGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddSensor').click(function() {
		plugin_alarme_addSensor();
	});
});

function plugin_alarme_delete_alarme_Sensor(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Sensor',
	id:id
	});
};

function plugin_alarme_timetoStart()
{
	plugin_alarme_chargement("plugin_alarme_test_span3");
	$('#plugin_alarme_test_span3').load('action.php',{
		action:'plugin_alarme_timetoStart',
		time:$('#plugin_alarme_timetoStart').val()
		}, function() {
		$('#plugin_alarme_test_span3').fadeIn();
		$('#plugin_alarme_test_span3').delay(5000);
		$('#plugin_alarme_test_span3').fadeOut();
	});
}

$(function(){
	$('#submit_plugin_alarme_timetoStart').click(function() {
		plugin_alarme_timetoStart();
	});
});


//Onglet Actions SMS
function plugin_alarme_test_SMS()
{
	if ($('#AlarmeUserId').val()=="")
	{
		alert ("Le champ Utilisateur est vide");
		return false;
	}
		
	if ($('#AlarmePassId').val()=="")
	{
		alert ('Le champ Mot de passe est vide');
		return false;
	}
	
	if ($('#AlarmeMsgId').val()=="")
	{
		alert ('Le champ Message est vide');
		return false;
	}
	
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_SMS',
		user:$('#AlarmeUserId').val(),
		pass:$('#AlarmePassId').val(),
		msg:$('#AlarmeMsgId').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_SMS').click(function() {
		plugin_alarme_test_SMS();
	});
});

function plugin_alarme_test_SMS_ponctuel(id)
{
	$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_SMS',
		id:id
		}, function() {
		$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}


function plugin_alarme_addActions_SMS()
{
	if ($('#AlarmeUserId').val()=="")
	{
		alert ("Le champ Utilisateur est vide");
		return false;
	}
		
	if ($('#AlarmePassId').val()=="")
	{
		alert ('Le champ Mot de passe est vide');
		return false;
	}
	
	if ($('#AlarmeMsgId').val()=="")
	{
		alert ('Le champ Message est vide');
		return false;
	}
	
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_sms',
		AlarmeTypeName:$('#AlarmeTypeId').val(),
		AlarmeUserName:$('#AlarmeUserId').val(),
		AlarmePassName:$('#AlarmePassId').val(),
		AlarmeMsgName:$('#AlarmeMsgId').val()
		}, function() {
		$('#AlarmeUserId').val('');
		$('#AlarmePassId').val('');
		$('#AlarmeMsgId').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_SMS').click(function() {
		plugin_alarme_addActions_SMS();
	});
});


function plugin_alarme_delete_alarme_SMS(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_SMS',
	id:id
	});
};

//Onglet Actions Email
function plugin_alarme_test_Email()
{
	if ($('#smtpServerAddr').val()=="" && $('#smtpServerPort').val()=="" && $('#smtpServerUser').val()=="" && $('#smtpServerPasswd').val()=="" 
	&& $('#EmailAddr').val()=="" && $('#EmailExp').val()=="" && $('#EmailOjt').val()=="" && $('#EmailMsg').val()=="")
	{
		alert ("Un champs obligatoire est vide");
		return false;
	}
		
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Email',	
		smtpServerAddr:$('#smtpServerAddr').val(),
		smtpServerPort:$('#smtpServerPort').val(),
		smtpServerSSL:$('#smtpServerSSL').val(),
		smtpServerUser:$('#smtpServerUser').val(),
		smtpServerPasswd:$('#smtpServerPasswd').val(),
		EmailAddr:$('#EmailAddr').val(),
		EmailExp:$('#EmailExp').val(),
		EmailOjt:$('#EmailOjt').val(),
		EmailMsg:$('#EmailMsg').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Email').click(function() {
		plugin_alarme_test_Email();
	});
});

function plugin_alarme_test_Email_ponctuel(id)
{
	$("#plugin_alarme_test_email"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Email',
		id:id
		}, function() {
		$("#plugin_alarme_test_email"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addActions_Email()
{
	if ($('#smtpServerAddr').val()=="" && $('#smtpServerPort').val()=="" && $('#smtpServerUser').val()=="" && $('#smtpServerPasswd').val()=="" 
	&& $('#EmailAddr').val()=="" && $('#EmailExp').val()=="" && $('#EmailOjt').val()=="" && $('#EmailMsg').val()=="")
	{
		alert ("Un champs obligatoire est vide");
		return false;
	}

	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Email',	
		smtpServerAddr:$('#smtpServerAddr').val(),
		smtpServerPort:$('#smtpServerPort').val(),
		smtpServerSSL:$('#smtpServerSSL').val(),
		smtpServerUser:$('#smtpServerUser').val(),
		smtpServerPasswd:$('#smtpServerPasswd').val(),
		EmailAddr:$('#EmailAddr').val(),
		EmailExp:$('#EmailExp').val(),
		EmailOjt:$('#EmailOjt').val(),
		EmailMsg:$('#EmailMsg').val()
		}, function() {
		$('#smtpServerAddr').val(''),
		$('#smtpServerPort').val(''),
		$('#smtpServerSSL').val(''),
		$('#smtpServerUser').val(''),
		$('#smtpServerPasswd').val('')
	});
};

$(function(){
	$('#submitAlarme_AddActions_Email').click(function() {
		plugin_alarme_addActions_Email();
	});
});

function plugin_alarme_delete_alarme_Email(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Email',
	id:id
	});
};

$(function(){
	$('#IconeEmailInfobulle').click(function() {
		$("#EmailInfobulle" ).slideToggle( "slow", function() {

		});
	});
});


//Onglet Actions GPIO
function plugin_alarme_test_GPIO()
{
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	if ($('#stateGPIO').val()=="")
	{
		alert ('Le champ Etat du GPIO est vide');
		return false;
	}
	
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_GPIO',
		numGPIO:$('#numGPIO').val(),
		stateGPIO:$('#stateGPIO').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_GPIO').click(function() {
		plugin_alarme_test_GPIO();
	});
});

function plugin_alarme_test_GPIO_ponctuel(id)
{
	$("#plugin_alarme_test_GPIO"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_GPIO',
		id:id
		}, function() {
		$("#plugin_alarme_test_sms"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addActions_GPIO()
{
	if ($('#descriptionGPIO').val()=="")
	{
		alert ("Le Description du GPIO est vide");
		return false;
	}
		
	if ($('#numGPIO').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	
	if ($('#stateGPIO').val()=="")
	{
		alert ('Le champ Etat du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_GPIO',
		descriptionGPIO:$('#descriptionGPIO').val(),
		numGPIO:$('#numGPIO').val(),
		stateGPIO:$('#stateGPIO').val()
		}, function() {
		$('#descriptionGPIO').val('');
		$('#numGPIO').val('');
		$('#stateGPIO').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_GPIO').click(function() {
		plugin_alarme_addActions_GPIO();
	});
});

function plugin_alarme_delete_alarme_GPIO(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_GPIO',
	id:id
	});
};

//Onglet Actions vocales
function plugin_alarme_test_Vocal()
{
	if ($('#MessageVocal').val()=="")
	{
		alert ('Le champ Message Vocal est vide');
		return false;
	}
		
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Vocal',
		MessageVocal:$('#MessageVocal').val()
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Vocal').click(function() {
		plugin_alarme_test_Vocal();
	});
});

function plugin_alarme_test_Vocal_ponctuel(id)
{
	$("#plugin_alarme_test_GPIO"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Vocal',
		id:id
		}, function() {
		$("#plugin_alarme_test_vocal"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addActions_Vocal()
{
	if ($('#MessageVocal').val()=="")
	{
		alert ('Le champ Numéro du GPIO est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");	
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Vocal',
		MessageVocal:$('#MessageVocal').val()
		}, function() {
		$('#MessageVocal').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_Vocal').click(function() {
		plugin_alarme_addActions_Vocal();
	});
});

function plugin_alarme_delete_alarme_Vocal(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_Vocal',
	id:id
	});
};

//////////////////
function plugin_HomeCheck_delete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_delete_HomeCheck',
	id:id
	});
}

function plugin_HomeCheck_RadioDelete(id){

	if(!confirm('Êtes vous sûr de vouloir faire ça ?')) return;
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_delete_Radio',
	id:id
	});
}

function plugin_alarme_delete_alarme_CommandeVocale(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_CommandeVocale',
	id:id
	});
};

//Onglet Camera 

$(function(){
	$('#IconeCameraInfobulle').click(function() {
		$("#CameraInfobulle" ).slideToggle( "slow", function() {
		});
	});
});

$(function(){
	$('#Plugin_Alarme_Camera').change(function() {
		if($("select option:selected").val()=="Photo")
		{
			$("#Plugin_Alarme_Video" ).slideToggle( "slow", function() {	
			});
			$("#Plugin_Alarme_Photo" ).slideToggle( "slow", function() {	
			});
		}
		if($("select option:selected").val()=="Video")
		{	
			$("#Plugin_Alarme_Photo" ).slideToggle( "slow", function() {	
			});
			$("#Plugin_Alarme_Video" ).slideToggle( "slow", function() {
			});
		}
	});
});


function plugin_alarme_test_Capture()
{
	if($("select option:selected").val()=="Photo")
	{	
		if ($('#Plugin_Alarme_Resolution_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		$('#submitAlarme_Camera_Test').text("Capture en cour...");
		plugin_alarme_chargement("xhrAlarme");
		$('#xhrAlarme').load('action.php',{
			action:'plugin_alarme_test_Camera',
			type:'Photo',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_V').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory').val()
			}, function() {
				$('#submitAlarme_Camera_Test').text("Capture terminée!")
				setTimeout(
				function()
				{
				  $('#submitAlarme_Camera_Test').text("Tester la capture");
				}, 3000)
			}
		);
	};
	if($("select option:selected").val()=="Video")
	{
		if ($('#Plugin_Alarme_Resolution_vid_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_vid_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_TimeToCapture').val()=="")
		{
			alert ('Le champ Temps de capture est vide');
			return false;
		}
		
		$('#submitAlarme_Camera_Test').text("Capture en cour...");
		plugin_alarme_chargement("xhrAlarme");
		$('#xhrAlarme').load('action.php',{
			action:'plugin_alarme_test_Camera',
			type:'Video',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_vid_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_vid_V').val(),
			Plugin_Alarme_TimeToCapture:$('#Plugin_Alarme_TimeToCapture').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption_vid').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory_vid').val()
			}, function() {
				$('#submitAlarme_Camera_Test').text("Capture terminée!")
				setTimeout(
				function()
				{
				  $('#submitAlarme_Camera_Test').text("Tester la capture");
				}, 3000)
				
		});
	}
}

$(function(){
	$('#submitAlarme_Camera_Test').click(function() {
		plugin_alarme_test_Capture();
	});
});

function plugin_alarme_add_alarme_camera(){
	if($("select option:selected").val()=="Photo")
	{	
		if ($('#Plugin_Alarme_Resolution_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		$('#submitAlarme_Camera_Add').text("Sauvegarde en cour...");
		plugin_alarme_chargement("plugin_alarme_save_span");
		$('#plugin_alarme_save_span').load('action.php',{
			action:'plugin_alarme_add_Camera',
			type:'Photo',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_V').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory').val()
			}, function() {
				$('#submitAlarme_Camera_Add').text("Enregistrer");
				$('#plugin_alarme_save_span').fadeIn();
				$('#plugin_alarme_save_span').delay(5000);
				$('#plugin_alarme_save_span').fadeOut();
		});
	}
	if($("select option:selected").val()=="Video")
	{
		if ($('#Plugin_Alarme_Resolution_vid_H').val()=="")
		{
			alert ('Le champ Résolution Hauteur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_Resolution_vid_L').val()=="")
		{
			alert ('Le champ Résolution Largeur est vide');
			return false;
		}
		
		if ($('#Plugin_Alarme_TimeToCapture').val()=="")
		{
			alert ('Le champ Temps de capture est vide');
			return false;
		}
		$('#submitAlarme_Camera_Add').text("Sauvegarde en cour...");
		plugin_alarme_chargement("plugin_alarme_save_span");
		$('#plugin_alarme_save_span').load('action.php',{
			action:'plugin_alarme_add_Camera',
			type:'Video',
			Plugin_Alarme_Resolution_H:$('#Plugin_Alarme_Resolution_vid_H').val(),
			Plugin_Alarme_Resolution_V:$('#Plugin_Alarme_Resolution_vid_V').val(),
			Plugin_Alarme_TimeToCapture:$('#Plugin_Alarme_TimeToCapture').val(),
			Plugin_Alarme_CameraOption:$('#Plugin_Alarme_CameraOption_vid').val(),
			Plugin_Alarme_CameraCopyDirectory:$('#Plugin_Alarme_CameraCopyDirectory_vid').val()
			}, function() {
				$('#submitAlarme_Camera_Add').text("Enregistrer");
				$('#plugin_alarme_save_span').fadeIn();
				$('#plugin_alarme_save_span').delay(5000);
				$('#plugin_alarme_save_span').fadeOut();
		});
	}
}

$(function(){
	$('#submitAlarme_Camera_Add').click(function() {
		plugin_alarme_add_alarme_camera();
	});
});

function plugin_alarme_delete_alarme_camera(name){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_alarme_camera',
	name:name
		}, function() {
	});
};




//Onglet Action URL
function plugin_alarme_test_URL()
{
	if ($('#Plugin_Alarme_ActionURL').val()=="")
	{
		alert ('Le champ URL est vide');
		return false;
	}
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_URL',
		actionUrl:encodeURIComponent($('#Plugin_Alarme_ActionURL').val())
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_URL').click(function() {
		plugin_alarme_test_URL();
	});
});

function plugin_alarme_test_actionsUrl_ponctuel(id)
{
	$("#plugin_alarme_test_actionsUrl"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_URL',
		id:id
		}, function() {
		$("#plugin_alarme_test_actionsUrl"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addURL()
{
if ($('#Plugin_Alarme_ActionURL').val()=="")
	{
		alert ('Le champ URL est vide');
		return false;
	}
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_URL',
		type:$('#Plugin_Alarme_TypeURL').val(),
		actionUrl:$('#Plugin_Alarme_ActionURL').val()
		}, function() {
		$('#Plugin_Alarme_ActionURL').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_URL').click(function() {
		plugin_alarme_addURL();
	});
});

function plugin_alarme_delete_Url(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_Url',
	id:id
	});
};

//Onglet Action Shell
function plugin_alarme_test_Shell()
{
	if ($('#Plugin_Alarme_ActionShell').val()=="")
	{
		alert ('Le champ Commande Shell est vide');
		return false;
	}
	plugin_alarme_chargement("plugin_alarme_test_span");
	$('#plugin_alarme_test_span').load('action.php',{
		action:'plugin_alarme_test_Shell',
		actionShell:encodeURIComponent($('#Plugin_Alarme_ActionShell').val())
		}, function() {
		$('#plugin_alarme_test_span').fadeIn();
		$('#plugin_alarme_test_span').delay(5000);
		$('#plugin_alarme_test_span').fadeOut();
	});
}

$(function(){
	$('#submitAlarme_test_Shell').click(function() {
		plugin_alarme_test_Shell();
	});
});

function plugin_alarme_test_actionsShell_ponctuel(id)
{
	$("#plugin_alarme_test_actionsShell"+id).toggleClass('fa fa-refresh').toggleClass('fa fa-spinner fa-spin');
	$('#plugin_alarme_test_spanId'+id).load('action.php',{
		action:'plugin_alarme_test_Shell',
		id:id
		}, function() {
		$("#plugin_alarme_test_actionsShell"+id).toggleClass('fa fa-spinner fa-spin').toggleClass('fa fa-refresh');
		$('#plugin_alarme_test_spanId'+id).fadeIn();
		$('#plugin_alarme_test_spanId'+id).delay(5000);
		$('#plugin_alarme_test_spanId'+id).fadeOut();
	});
}

function plugin_alarme_addShell()
{
if ($('#Plugin_Alarme_ActionShell').val()=="")
	{
		alert ('Le champ Commande Shell est vide');
		return false;
	}
	$('#xhrAlarme').load('action.php',{
		action:'plugin_alarme_add_Shell',
		actionShell:$('#Plugin_Alarme_ActionShell').val()
		}, function() {
		$('#Plugin_Alarme_ActionShell').val('');
	});
};

$(function(){
	$('#submitAlarme_AddActions_Shell').click(function() {
		plugin_alarme_addShell();
	});
});

function plugin_alarme_delete_Shell(id){
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
	action:'plugin_alarme_delete_Shell',
	id:id
	});
};

//Onglet Widget
function plugin_alarme_updateRefreshPhoto(obj)
{
	var button = $(obj);
	var input = button.prev("input");
	var icon = button.find("i");
	
	$.post( "action.php",
	{ 
	  action: "plugin_alarme_updateRefresh",
	  champs: input.attr("id"),
	  value: input.val()
	},
		function() {
			icon.addClass('active');
			setTimeout(
				function()
				{
				  icon.removeClass('active');
				}, 3000
			);
		}
    );
};

$(function(){
	$('#submitAlarme_AddRadio').click(function() {
		plugin_HomeCheckRadio_save();
	});
});


function plugin_HomeCheckRadio_save()
{
	if ($('#descriptionGenericRadio').val()=="")
	{
		alert ('Le champ description est vide');
		return false;
	}
	plugin_alarme_chargement("xhrAlarme");
	$('#xhrAlarme').load('action.php',{
		action:'HomeCheck_save_Radio',
		descriptionGenericRadio:$('#descriptionGenericRadio').val(),
		radioCodeGenericRadioOn:$('#radioCodeGenericRadioOn').val(),
		radioCodeGenericRadioOff:$('#radioCodeGenericRadioOff').val(),
		radioCodeGenericIsAlarm:$('#radioCodeGenericIsAlarm').val(),
		onGenericRadio:$('#onGenericRadio').val(),
		offGenericRadio:$('#offGenericRadio').val(),
		SensorType:$('#SensorType').val(),
		}, function() {
		$('#descriptionGenericRadio').val('');
		$('#radioCodeGenericRadioOn').val();
		$('#radioCodeGenericRadioOff').val();
		$('#radioCodeGenericIsAlarm').val();
		$('#onGenericRadio').val();
		$('#offGenericRadio').val();
		$('#SensorType').val();
	});
};

//Import
function plugin_HomeCheck_import(element){
	var form = $('.import');
 	var data = form.toData();
	
	data.action = 'HomeCheck_import_HomeCheck';
	$.action(data,
		function(response){
			alert(response.message);
			form.find('input').val('');
			location.reload();
		}
	);
}




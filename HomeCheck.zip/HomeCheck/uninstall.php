<?php
require_once(dirname(__FILE__).'/class/HMalarmeSensor.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensorRadio.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSMS.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeEmail.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeGPIO.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeActionVocal.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeCommandeVocale.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeURL.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeConf.class.php');
require_once(dirname(__FILE__).'/class/HMalarmePeople.class.php');

$table = new Home_Check();
$table->drop();

$table = new AlarmeSensor();
$table->drop();

$table = new AlarmeSensorRadio();
$table->drop();

$table = new AlarmeSMS();
$table->drop();

$table = new AlarmeEmail();
$table->drop();

$table = new AlarmeGPIO();
$table->drop();

$table1 = new AlarmeActionVocal();
$table1->drop();

$table1 = new AlarmeCommandeVocale();
$table1->drop();

$table1 = new AlarmeURL();
$table1->drop();

$table1 = new AlarmeConf();
$table1->drop();

$table_section = new Section();
$id_section = $table_section->load(array("label"=>"Home_Check"))->getId();
$table_section->delete(array('label'=>'Home_Check'));

$table_right = new Right();
$table_right->delete(array('section'=>$id_section));


?>

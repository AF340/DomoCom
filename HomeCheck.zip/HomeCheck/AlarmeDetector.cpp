#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <sstream> 
#include <iostream>
#include <sys/wait.h>

//Librairie pour GPIO
#include <wiringPi.h>

/*
Par Alexandre Rault (alex.rault@laposte.net)
Licence : CC by nc sa
Version: 1

Programme d'initialisation des GPIO et de création des interruptions processeurs en cas de bascule d'un entrée.


Le programme est compilable avec la commande : 
g++ AlarmeDetector.cpp -o AlarmeDetector -lwiringPi
sudo chown root:www-data AlarmeDetector
sudo chmod 4777 AlarmeDetector

http://127.0.0.1/yana-server/action.php?
 */

 
using namespace std;
FILE *log;
string ip;
string urlwget;
int pin;
int timetosleep;
int mode;
unsigned int last_interrupt_time = 0;



void FonctionAlarme (void)
{
	unsigned int interrupt_time = millis();
	if (abs(interrupt_time - last_interrupt_time) < 100){
	   return ;
	}
	last_interrupt_time = interrupt_time;
	printf (" Changement d'état! \n") ;
	if (mode == 1)
	{
		//Appel de l'url de déclenchement de l'alarme
		urlwget = "wget -q -O /dev/null http://" + ip + "/yana-server/action.php?action=Plugin_Alarme_Start_Action > /dev/null &";
		system(urlwget.c_str());

		log = fopen("/var/log/yana_plugin_alarme.txt" , "a" );	
		fputs(urlwget.c_str(),log);
		fclose(log);
		
		exit(EXIT_SUCCESS);
	}
	else if (mode == 0)
	{
		//Appel de l'url de déclenchement de l'alarme
		urlwget = "wget -q -O /dev/null http://" + ip + "/yana-server/action.php?action=Plugin_Alarme_Start_Switch > /dev/null &";
		system(urlwget.c_str());
		log = fopen("/var/log/yana_plugin_alarme.txt" , "a" );	
		fputs(urlwget.c_str(),log);
		fclose(log);
	}
	else
	{
		cout << "mode non déclaré"<< endl;
	}
  return ;
}


int main(int argc, char** argv) 
{
	if (setuid(0))
    {
        perror("setuid");
        return 1;
    } 
	
	//verif des arguments
	if (!argc==3)
	{
		cout << "Arguments manquants" << endl;
	}
	else 
	{
		//Déclaration des constantes
		ip = "127.0.0.1";
		pin = atoi(argv[1]);
		timetosleep = atoi(argv[2]);
		mode = atoi(argv[3]);
		
		time_t t = time(NULL);

		log = fopen("/var/log/yana_plugin_alarme.txt" , "w+" );
		fprintf(log, "Démarrage du programme : %s ",ctime(&t));
		fclose(log);
		
		sleep(timetosleep);
		
		//test wiring pi
		if (wiringPiSetup() < 0) 
		{
			cout << "Erreur lors de l'initialisation de WiringPi" << endl;
		}
		else
		{
			log = fopen("/var/log/yana_plugin_alarme.txt" , "a" );	
			fputs("Wiring Pi ok \n",log);
			fclose(log);
			//Test de la création de l'interrupt
			if (wiringPiISR (pin, INT_EDGE_BOTH, &FonctionAlarme) < 0)
			{
				cout << "Erreur lors de l'initialisation de de la fonction interrupt" << endl;
			}
			else
			{
				cout << "Interrupt ok" << endl;
				cout << "Waiting ... " << endl;

				while (true)
				{
					//On peux laisser dormir le programme, l'interrupt fonctionne
					sleep(20);
				}
			}
		}
	}
}
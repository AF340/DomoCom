<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeCommandeVocale extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeCommandeVocale';
	protected $CLASS_NAME = 'AlarmeCommandeVocale';
	protected $object_fields = 
	array(
		'id'=>'key',
		'type'=>'string',
		'commande'=>'string',
		'confidence'=>'int',
	);

	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}

	
	function getType()
	{
		return $this->type;
	}

	function setType($type)
	{
		$this->type = $type;
	}

	
		function getCommande()
	{
		return $this->commande;
	}

	function setCommande($commande)
	{
		$this->commande = $commande;
	}
	
	
		function getConfidence()
	{
		return $this->confidence;
	}

	function setConfidence($confidence)
	{
		$this->confidence = $confidence;
	}	
}
?>
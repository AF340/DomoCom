<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeShell extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeShell';
	protected $CLASS_NAME = 'AlarmeShell';
	protected $object_fields = 
	array(
		'id'=>'key',
		'shell'=>'string'
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}
	
		function getShell()
	{
		return $this->shell;
	}

	function setShell($shell)
	{
		$this->shell = $shell;
	}
}
?>
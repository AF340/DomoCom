<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeEmail extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeEmail';
	protected $CLASS_NAME = 'AlarmeEmail';
	protected $object_fields = 
	array(
		'id'=>'key',
		'smtpServerAddr'=>'string',
		'smtpServerPort'=>'int',
		'smtpServerSSL'=>'string',
		'smtpServerUser'=>'string',
		'smtpServerPasswd'=>'string',
		'EmailAddr'=>'int',
		'EmailExp'=>'string',
		'EmailOjt'=>'string',
		'EmailMsg'=>'string',
	);
	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}

	
	
	function getSmtpServerAddr()
	{
		return $this->smtpServerAddr;
	}

	function setSmtpServerAddr($smtpServerAddr)
	{
		$this->smtpServerAddr = $smtpServerAddr;
	}

	
	
	function getSmtpServerPort()
	{
		return $this->smtpServerPort;
	}

	function setSmtpServerPort($smtpServerPort)
	{
		$this->smtpServerPort = $smtpServerPort;
	}
	
	
	function getSmtpServerSSL()
	{
		return $this->smtpServerSSL;
	}

	function setSmtpServerSSL($smtpServerSSL)
	{
		$this->smtpServerSSL = $smtpServerSSL;
	}
	
	
	function getSmtpServerUser()
	{
		return $this->smtpServerUser;
	}

	function setSmtpServerUser($smtpServerUser)
	{
		$this->smtpServerUser = $smtpServerUser;
	}

	
	function getSmtpServerPasswd()
	{
		return $this->smtpServerPasswd;
	}

	function setSmtpServerPasswd($smtpServerPasswd)
	{
		$this->smtpServerPasswd = $smtpServerPasswd;
	}
	
	
	function getEmailAddr()
	{
		return $this->EmailAddr;
	}

	function setEmailAddr($EmailAddr)
	{
		$this->EmailAddr = $EmailAddr;
	}
	
	
	function getEmailExp()
	{
		return $this->EmailExp;
	}

	function setEmailExp($EmailExp)
	{
		$this->EmailExp = $EmailExp;
	}
	
	
	function getEmailOjt()
	{
		return $this->EmailOjt;
	}

	function setEmailOjt($EmailOjt)
	{
		$this->EmailOjt = $EmailOjt;
	}

	
	function getEmailMsg()
	{
		return $this->EmailMsg;
	}

	function setEmailMsg($EmailMsg)
	{
		$this->EmailMsg = $EmailMsg;
	}
	
}
?>
<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeSMS extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeSMS';
	protected $CLASS_NAME = 'AlarmeSMS';
	protected $object_fields = 
	array(
		'id'=>'key',
		'type'=>'string',
		'identifiant_user'=>'string',
		'identifiant_mdp'=>'string',
		'message'=>'string'
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}

	
	function getType()
	{
		return $this->type;
	}

	function setType($type)
	{
		$this->type = $type;
	}

	
		function getIdentifiant_user()
	{
		return $this->identifiant_user;
	}

	function setIdentifiant_user($identifiant_user)
	{
		$this->identifiant_user = $identifiant_user;
	}
	
	
	function getIdentifiant_mdp()
	{
		return $this->identifiant_mdp;
	}

	function setIdentifiant_mdp($identifiant_mdp)
	{
		$this->identifiant_mdp = $identifiant_mdp;
	}
	
	function getMessage()
	{
		return $this->message;
	}

	function setMessage($message)
	{
		$this->message = $message;
	}

	
	
}
?>
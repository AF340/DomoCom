<?php
/*
@name Home_Check
@author alex f <alexandre.franciosa@gmail.com>
@link http://blog.idleman.fr
@licence CC by nc sa 
@version 1.2.0 
@description Plugin HomeCheck.
*/

class AlarmeActionVocal extends SQLiteEntity
{
	protected $TABLE_NAME = 'plugin_AlarmeActionVocal';
	protected $CLASS_NAME = 'AlarmeActionVocal';
	protected $object_fields = 
	array(
		'id'=>'key',
		'MessageVocal'=>'string'
	);

	
	function __construct($tag="rw")
	{
		parent::__construct($tag);
	}
	
	function getId()
	{
		return $this->id;
	}
	
	function setId($id)
	{
		$this->id = $id;
	}

	
	function getMessageVocal()
	{
		return $this->MessageVocal;
	}

	function setMessageVocal($MessageVocal)
	{
		$this->MessageVocal = $MessageVocal;
	}
}
?>
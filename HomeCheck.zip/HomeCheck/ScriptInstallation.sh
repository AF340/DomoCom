#!/bin/sh

sudo chown root:www-data AlarmeDetector
sudo chmod 4777 AlarmeDetector
sudo chown root:www-data AlarmeStop
sudo chmod 4777 AlarmeStop
sudo chown root:www-data codesend
sudo chmod 4777 codesend
sudo chown www-data ./camera
sudo chown www-data ./cameraWidget

sudo usermod -a -G video www-data 
sudo echo 'SUBSYSTEM=="vchiq",GROUP="video",MODE="0660"' > /etc/udev/rules.d/10-vchiq-permissions.rules

sudo apt-get -y install curl
sudo apt-get -y install gpac

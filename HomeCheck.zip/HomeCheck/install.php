<?php
require_once(dirname(__FILE__).'/class/HMalarmeSensor.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSensorRadio.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeSMS.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeEmail.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeGPIO.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeActionVocal.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeCommandeVocale.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeURL.class.php');
require_once(dirname(__FILE__).'/class/HMalarmeConf.class.php');
require_once(dirname(__FILE__).'/class/HMalarmePeople.class.php');

$table = new Home_Check();
$table->create();

$table1 = new AlarmeSensor();
$table1->create();

$table1 = new AlarmeSensorRadio();
$table1->create();


$table = new AlarmeSMS();
$table->create();

$table = new AlarmeEmail();
$table->create();

$table = new AlarmeGPIO();
$table->create();

$table1 = new AlarmeActionVocal();
$table1->create();

$table1 = new AlarmeCommandeVocale();
$table1->create();

$table1 = new AlarmeURL();
$table1->create();

$table1 = new AlarmeConf();
$table1->create();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_timetoStart');
$alarme_conf->setValue('10');
$alarme_conf->save();  

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_widget_color');
$alarme_conf->setValue('#50597b');
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_Start');
$alarme_conf->setValue('0');
$alarme_conf->save();  

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_RefreshWidget');
$alarme_conf->setValue('8000');
$alarme_conf->save();  

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_RefreshWidgetPhoto');
$alarme_conf->setValue('30000');
$alarme_conf->save(); 

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_CameraDirectory');
$alarme_conf->setValue(getcwd()."/plugins/Home_Check/camera/");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraType');
$alarme_conf->setValue("Photo");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraResH');
$alarme_conf->setValue("");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraResV');
$alarme_conf->setValue("");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraTime');
$alarme_conf->setValue("");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraOption');
$alarme_conf->setValue("");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('Plugin_Alarme_CameraCopyDirectory');
$alarme_conf->setValue("");
$alarme_conf->save();

$alarme_conf = new AlarmeConf();
$alarme_conf->setConf('plugin_alarme_WidgetCameraOption');
$alarme_conf->setValue("");
$alarme_conf->save();

$s1 = New Section();
$s1->setLabel('Home_Check');
$s1->save();

$r1 = New Right();
$r1->setSection($s1->getId());
$r1->setRead('1');
$r1->setDelete('1');
$r1->setCreate('1');
$r1->setUpdate('1');
$r1->setRank('1');
$r1->save();
?>